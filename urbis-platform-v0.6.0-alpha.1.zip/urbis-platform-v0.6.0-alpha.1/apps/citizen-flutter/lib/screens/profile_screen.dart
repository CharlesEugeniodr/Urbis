import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/auth_store.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthStore>();
    final u = auth.user ?? {};
    return Scaffold(
      appBar: AppBar(title: const Text('Perfil')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const CircleAvatar(radius: 40, child: Icon(Icons.person, size: 42)),
        const SizedBox(height: 16),
        Center(child: Text(u['displayName']?.toString() ?? u['display_name']?.toString() ?? 'Cidadão', style: Theme.of(context).textTheme.titleLarge)),
        Center(child: Text(u['email']?.toString() ?? '')),
        const SizedBox(height: 24),
        FilledButton.tonal(onPressed: () => auth.logout(), child: const Text('Sair')),
      ]),
    );
  }
}
