import 'package:flutter_test/flutter_test.dart';
import 'package:urbis_citizen/core/api_client.dart';

void main(){test('API base URL is configured',(){expect(ApiClient.baseUrl,isNotEmpty);});}
