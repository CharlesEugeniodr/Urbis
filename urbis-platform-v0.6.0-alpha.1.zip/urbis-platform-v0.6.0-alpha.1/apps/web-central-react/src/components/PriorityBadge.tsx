import React from 'react';
export function PriorityBadge({priority}:{priority?:string}){return <span className={`badge priority-${String(priority||'NORMAL').toLowerCase()}`}>{priority||'NORMAL'}</span>;}
