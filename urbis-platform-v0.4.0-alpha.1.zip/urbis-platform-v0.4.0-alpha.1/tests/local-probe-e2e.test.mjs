import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import fs from 'node:fs';

const PORT=3217,BASE=`http://127.0.0.1:${PORT}`,PASSWORD='UrbisLocal!2026';
const geo=JSON.parse(fs.readFileSync(new URL('../data/territorial/logradouros_parauapebas_2025.operational.geojson',import.meta.url),'utf8'));
const [lon,lat]=geo.features[0].geometry.coordinates[0][0];
let proc,citizenToken,operatorToken,fieldToken;
async function waitHealth(){for(let i=0;i<80;i++){try{const r=await fetch(BASE+'/health');if(r.ok)return await r.json();}catch{}await new Promise(r=>setTimeout(r,75));}throw new Error('probe_not_ready');}
async function login(email){const r=await fetch(BASE+'/v1/auth/login',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({email,password:PASSWORD})});const j=await r.json();assert.ok(r.ok,JSON.stringify(j));return j.accessToken;}
async function post(url,body,token){const r=await fetch(BASE+url,{method:'POST',headers:{'content-type':'application/json',...(token?{authorization:'Bearer '+token}:{})},body:JSON.stringify(body)});const j=await r.json();assert.ok(r.ok,JSON.stringify(j));return j;}
async function get(url,token){const r=await fetch(BASE+url,{headers:token?{authorization:'Bearer '+token}:{}});const j=await r.json();return {r,j};}

test.before(async()=>{proc=spawn(process.execPath,['tools/local-probe-server.mjs'],{cwd:new URL('..',import.meta.url),env:{...process.env,URBIS_PORT:String(PORT)},stdio:['ignore','pipe','pipe']});await waitHealth();[citizenToken,operatorToken,fieldToken]=await Promise.all([login('citizen@urbis.local'),login('operator@urbis.local'),login('field@urbis.local')]);});
test.after(async()=>{if(proc&&!proc.killed){proc.kill('SIGTERM');await new Promise(r=>proc.once('exit',r));}});

test('RBAC bloqueia lista operacional para cidadão',async()=>{const {r,j}=await get('/v1/occurrences',citizenToken);assert.equal(r.status,403);assert.equal(j.error,'forbidden');});

test('fluxo autenticado: cidadão → ocorrência → evidência → ICI → triagem → OS → resolução',async()=>{
  const a=await post('/v1/occurrences',{categoryCode:'PAVEMENT',description:'teste operacional A',latitude:lat,longitude:lon,clientRequestId:'e2e-a'},citizenToken);
  assert.match(a.occurrence.protocol,/^URB-\d{8}-\d{7}$/);assert.equal(a.occurrence.territory.matched,true);assert.equal(a.occurrence.evidenceState,'GEO_VALIDATED');
  const ev=await post(`/v1/occurrences/${a.occurrence.id}/evidence`,{filename:'buraco.jpg',mediaType:'image/jpeg',dataBase64:Buffer.from('imagem-de-prova-e2e').toString('base64'),capturedAt:new Date().toISOString(),latitude:lat,longitude:lon},citizenToken);
  assert.equal(ev.evidence.hashVerified,true);assert.match(ev.evidence.sha256,/^[a-f0-9]{64}$/);assert.ok(ev.evidence.ici.score>0);assert.equal(ev.occurrence.evidenceState,'EVIDENCE_VALIDATED');
  const auth=await post(`/v1/occurrences/${a.occurrence.id}/evidence/${ev.evidence.id}/authority-validate`,{},operatorToken);assert.equal(auth.occurrence.evidenceState,'AUTHORITY_VALIDATED');assert.ok(auth.occurrence.ici.score>=ev.evidence.ici.score);
  const b=await post('/v1/occurrences',{categoryCode:'PAVEMENT',description:'teste operacional B',latitude:lat,longitude:lon+0.00001,clientRequestId:'e2e-b'},citizenToken);assert.equal(b.occurrence.duplicateSuspected,true);
  const t=await post(`/v1/occurrences/${a.occurrence.id}/triage`,{decision:'PROCEDENT'},operatorToken);assert.equal(t.occurrence.status,'DISPATCHED');assert.ok(t.workOrder.id);
  const started=await post(`/v1/work-orders/${t.workOrder.id}/status`,{status:'IN_PROGRESS'},fieldToken);assert.equal(started.occurrence.status,'IN_SERVICE');
  const done=await post(`/v1/work-orders/${t.workOrder.id}/status`,{status:'COMPLETED',result:{proof:'e2e'}},fieldToken);assert.equal(done.occurrence.status,'RESOLVED');
  const mine=await get('/v1/me/occurrences',citizenToken);assert.ok(mine.r.ok);assert.equal(mine.j.count,2);
});

test('idempotência autenticada por clientRequestId impede protocolo duplicado por retry',async()=>{
  const x=await post('/v1/occurrences',{categoryCode:'LIGHTING',latitude:lat,longitude:lon,clientRequestId:'retry-fixed'},citizenToken);
  const y=await post('/v1/occurrences',{categoryCode:'LIGHTING',latitude:lat,longitude:lon,clientRequestId:'retry-fixed'},citizenToken);
  assert.equal(y.idempotent,true);assert.equal(x.occurrence.id,y.occurrence.id);assert.equal(x.occurrence.protocol,y.occurrence.protocol);
});

test('WebSocket exige token operacional e recebe atualização',async()=>{
  assert.equal(typeof WebSocket,'function');
  const ws=new WebSocket(`ws://127.0.0.1:${PORT}/ws/occurrences?access_token=${encodeURIComponent(operatorToken)}`);
  await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true});});
  const message=new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(new Error('ws_timeout')),3000);const listener=e=>{const d=JSON.parse(String(e.data));if(d.topic==='occurrence.created'){clearTimeout(timer);ws.removeEventListener('message',listener);resolve(d);}};ws.addEventListener('message',listener);});
  const created=await post('/v1/occurrences',{categoryCode:'WATER',description:'ws test',latitude:lat,longitude:lon,clientRequestId:'ws-event'},citizenToken);
  const e=await message;assert.equal(e.entityId,created.occurrence.id);ws.close();
});
