import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/api_client.dart';
import 'core/auth_store.dart';
import 'core/theme.dart';
import 'screens/home_screen.dart';
import 'screens/login_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final api = ApiClient();
  final auth = AuthStore(api);
  await auth.bootstrap();
  runApp(UrbisApp(api: api, auth: auth));
}

class UrbisApp extends StatelessWidget {
  const UrbisApp({super.key, required this.api, required this.auth});
  final ApiClient api;
  final AuthStore auth;

  @override
  Widget build(BuildContext context) => MultiProvider(
        providers: [
          Provider<ApiClient>.value(value: api),
          ChangeNotifierProvider<AuthStore>.value(value: auth),
        ],
        child: MaterialApp(
          title: 'URBIS Cidadão',
          debugShowCheckedModeBanner: false,
          theme: AppTheme.light,
          home: Consumer<AuthStore>(
            builder: (_, state, __) {
              if (state.isLoading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
              return state.isAuthenticated ? const HomeScreen() : const LoginScreen();
            },
          ),
        ),
      );
}
