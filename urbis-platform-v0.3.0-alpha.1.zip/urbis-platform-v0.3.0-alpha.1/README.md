# URBIS

**Cidades Inteligentes, Pessoas Ativas**  
**Você informa. A cidade evolui.**  
**Uma cidade melhor começa com você.**

Produto de propriedade de **Sigma SIHF Soluções Analíticas S/A — CNPJ 01.851.824/0001-38**.

## v0.3.0-alpha.1 — núcleo operacional

Esta versão executa o primeiro fluxo completo do produto:

`cidadão → GPS → protocolo → logradouro/CEP/bairro → duplicidade → triagem → despacho → ordem de serviço → atendimento → resolução → WebSocket`

A camada territorial continua baseada nos **10.997 segmentos válidos** do dataset `Logradouros 2025 2.geojson`, com **82 registros em quarentena** preservados sem correção silenciosa.

## Executar imediatamente no Windows

Dê duplo clique em:

`START_URBIS_PANEL.bat`

ou execute:

```bash
npm run probe
```

Depois abra:

`http://127.0.0.1:3100/panel/`

O painel local permite registrar uma ocorrência em um ponto da malha, obter protocolo, executar triagem, gerar ordem de serviço, iniciar atendimento e concluir a ocorrência. As mudanças chegam ao painel via WebSocket nativo.

## Endpoints da prova operacional

- `GET /health`
- `GET /v1/operations/summary`
- `GET /v1/occurrences`
- `POST /v1/occurrences`
- `GET /v1/occurrences/:id`
- `POST /v1/occurrences/:id/triage`
- `GET /v1/work-orders`
- `POST /v1/work-orders/:id/status`
- `GET /v1/territory/stats`
- `GET /v1/territory/cep/:cep`
- `GET /v1/territory/nearest?lat=...&lon=...`
- `POST /v1/resilience/evaluate`
- WebSocket: `/ws/occurrences`

## PostgreSQL/PostGIS

As migrations 008 e 009 acrescentam:

- protocolo;
- idempotência;
- snapshot territorial;
- candidatos de duplicidade;
- regras de despacho;
- alvos de integração;
- outbox de eventos.

Em um ambiente com Docker:

```bash
cd infra
docker compose up -d
```

As migrations são carregadas em ordem na criação de um volume PostgreSQL novo.

## Testes

```bash
npm run test:all
```

A versão contém 17 testes automatizados: PLANCON, território, núcleo operacional e fluxo E2E com WebSocket.

## Integridade

O sistema não atribui significado aos códigos territoriais não documentados e não trata SLAs técnicos do alpha como prazos oficiais. A responsabilidade administrativa concreta é configurável por `integration_targets`.

Documentação detalhada: `docs/OPERATIONAL_CORE.md` e `docs/IMPLEMENTATION_STATUS.md`.
