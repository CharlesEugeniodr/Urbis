import 'package:flutter/material.dart';
import 'api_client.dart';

class AuthStore extends ChangeNotifier {
  AuthStore(this.api);
  final ApiClient api;
  Map<String, dynamic>? user;
  bool isLoading = true;

  bool get isAuthenticated => user != null && api.hasToken;

  Future<void> bootstrap() async {
    isLoading = true;
    notifyListeners();
    await api.init();
    if (api.hasToken) {
      try {
        final result = await api.me();
        user = Map<String, dynamic>.from(result['user'] ?? {});
      } catch (_) {
        await api.setToken(null);
        user = null;
      }
    }
    isLoading = false;
    notifyListeners();
  }

  Future<void> login(String email, String password) async {
    final result = await api.login(email, password);
    user = Map<String, dynamic>.from(result['user'] ?? {});
    notifyListeners();
  }

  Future<void> register(String email, String password, String displayName, String? cpf) async {
    final result = await api.register(email: email, password: password, displayName: displayName, cpf: cpf);
    user = Map<String, dynamic>.from(result['user'] ?? {});
    notifyListeners();
  }

  Future<void> logout() async {
    await api.setToken(null);
    user = null;
    notifyListeners();
  }
}
