import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/api_client.dart';
import 'occurrence_detail_screen.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});
  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  Future<Map<String, dynamic>>? future;
  @override
  void didChangeDependencies() { super.didChangeDependencies(); future ??= context.read<ApiClient>().myOccurrences(); }
  Future<void> refresh() async { setState(() => future = context.read<ApiClient>().myOccurrences()); await future; }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Minhas ocorrências')),
        body: FutureBuilder<Map<String, dynamic>>(
          future: future,
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
            if (snapshot.hasError) return Center(child: Text(snapshot.error.toString()));
            final records = List<Map<String, dynamic>>.from((snapshot.data?['records'] ?? []).map((e) => Map<String, dynamic>.from(e)));
            return RefreshIndicator(
              onRefresh: refresh,
              child: ListView.builder(
                itemCount: records.length,
                itemBuilder: (_, i) {
                  final o = records[i];
                  return ListTile(
                    title: Text(o['protocol']?.toString() ?? o['id'].toString()),
                    subtitle: Text('${o['category_code'] ?? o['categoryCode'] ?? ''} • ${o['status'] ?? ''}'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => OccurrenceDetailScreen(occurrenceId: o['id'].toString()))),
                  );
                },
              ),
            );
          },
        ),
      );
}
