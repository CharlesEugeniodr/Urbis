import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { evaluateResilience } from '../core/risk-engine.mjs';
import { advanceWorkOrder, buildOccurrence, duplicateCandidates, nearestStreet, triageOccurrence } from '../core/operation-core.mjs';
import { assessICI, ALLOWED_MEDIA_TYPES, decodeEvidenceBase64, extensionForMediaType, sanitizeFilename, sha256 } from '../core/evidence-core.mjs';
import { bearerToken, hasPermission, hashPassword, issueAccessToken, normalizeEmail, redactUser, requirePermission, verifyAccessToken, verifyPassword } from '../core/security-core.mjs';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const root=path.join(__dirname,'..');
const VERSION='0.4.0-alpha.1';
const PORT=Number(process.env.URBIS_PORT??3100);
const HOST=process.env.URBIS_HOST??'127.0.0.1';
const LOOPBACK=new Set(['127.0.0.1','localhost','::1']).has(HOST);
const DEMO_PASSWORD=process.env.URBIS_DEMO_PASSWORD??'UrbisLocal!2026';
const TOKEN_SECRET=process.env.URBIS_TOKEN_SECRET??(LOOPBACK?'URBIS_LOCAL_ALPHA_TOKEN_SECRET_CHANGE_BEFORE_DEPLOYMENT_2026':null);
if(!TOKEN_SECRET) throw new Error('URBIS_TOKEN_SECRET is required outside loopback mode');

const csv=fs.readFileSync(path.join(root,'data/territorial/ceps_parauapebas_2025.csv'),'utf8').split(/\r?\n/);
const header=csv[0].split(',');
function parseCsvLine(line){const out=[];let cur='',q=false;for(let i=0;i<line.length;i++){const c=line[i];if(c==='"'){if(q&&line[i+1]==='"'){cur+='"';i++;}else q=!q;}else if(c===','&&!q){out.push(cur);cur='';}else cur+=c;}out.push(cur);return Object.fromEntries(header.map((h,i)=>[h,out[i]??'']));}
const cepIndex=new Map();
for(const line of csv.slice(1)){if(!line.trim())continue;const r=parseCsvLine(line);if(!cepIndex.has(r.cep))cepIndex.set(r.cep,[]);cepIndex.get(r.cep).push(r);}

const streetsPath=path.join(root,'data/territorial/logradouros_parauapebas_2025.operational.geojson');
const streets=JSON.parse(fs.readFileSync(streetsPath,'utf8'));
const streetMeta=JSON.parse(fs.readFileSync(path.join(root,'data/territorial/logradouros_parauapebas_2025.metadata.json'),'utf8'));
const operationalFeatures=streets.features;
const evidenceRoot=path.join(root,'storage/evidence');
fs.mkdirSync(evidenceRoot,{recursive:true});

const state={occurrences:[],workOrders:[],events:[],evidence:[],users:[],protocolSeq:1};
const wsClients=new Set();
function seedUser(email,displayName,roles){const user={id:crypto.randomUUID(),email:normalizeEmail(email),displayName,roles,passwordHash:hashPassword(DEMO_PASSWORD),createdAt:new Date().toISOString()};state.users.push(user);return user;}
seedUser('citizen@urbis.local','Cidadão Demonstração',['CITIZEN']);
seedUser('operator@urbis.local','Operador URBIS',['OPERATOR']);
seedUser('field@urbis.local','Equipe de Campo',['FIELD_AGENT']);
seedUser('manager@urbis.local','Gestor URBIS',['MANAGER']);
seedUser('admin@urbis.local','Administrador URBIS',['ADMIN']);

function protocol(){return `URB-${new Date().toISOString().slice(0,10).replaceAll('-','')}-${String(state.protocolSeq++).padStart(7,'0')}`;}
function event(topic,entityType,entityId,payload){const e={topic,entityType,entityId,payload,at:new Date().toISOString()};state.events.push(e);for(const s of wsClients)sendWs(s,JSON.stringify(e));return e;}
function corsHeaders(){return {'access-control-allow-origin':'*','access-control-allow-headers':'content-type,authorization','access-control-allow-methods':'GET,POST,OPTIONS'};}
function send(res,code,obj,extra={}){const body=JSON.stringify(obj,null,2);res.writeHead(code,{'content-type':'application/json; charset=utf-8',...corsHeaders(),...extra});res.end(body);}
function sendFile(res,file,contentType){res.writeHead(200,{'content-type':contentType,...corsHeaders(),'cache-control':'no-store'});fs.createReadStream(file).pipe(res);}
function bodyJson(req){return new Promise((resolve,reject)=>{let body='';const limit=14_000_000;req.on('data',c=>{body+=c;if(body.length>limit){reject(new Error('body_too_large'));req.destroy();}});req.on('end',()=>{try{resolve(JSON.parse(body||'{}'));}catch{reject(new Error('invalid_json'));}});req.on('error',reject);});}
function currentUser(req){const token=bearerToken(req.headers);if(!token)return null;const claims=verifyAccessToken(token,{secret:TOKEN_SECRET});const user=state.users.find(u=>u.id===claims.sub);if(!user||user.active===false)return null;return {...redactUser(user),roles:claims.roles};}
function authorized(req,permission){const user=currentUser(req);requirePermission(user,permission);return user;}
function canReadOccurrence(user,o){return hasPermission(user,'occurrence:read:any')||(hasPermission(user,'occurrence:read:self')&&o.reporterUserId===user.id);}
function canUploadEvidence(user,o){return hasPermission(user,'evidence:upload:any')||(hasPermission(user,'evidence:upload:self')&&o.reporterUserId===user.id);}

function eachCoord(geom,fn){if(!geom)return;const c=geom.coordinates;if(geom.type==='MultiLineString')for(const line of c)for(const p of line)fn(p);else if(geom.type==='LineString')for(const p of c)fn(p);}
function featureBounds(ft){let b=[180,90,-180,-90];eachCoord(ft.geometry,([x,y])=>{b[0]=Math.min(b[0],x);b[1]=Math.min(b[1],y);b[2]=Math.max(b[2],x);b[3]=Math.max(b[3],y);});return b;}
const features=operationalFeatures.map(ft=>({ft,bbox:featureBounds(ft)}));
function intersects(a,b){return a[0]<=b[2]&&a[2]>=b[0]&&a[1]<=b[3]&&a[3]>=b[1];}
function parseBbox(v){if(!v)return null;const p=v.split(',').map(Number);return p.length===4&&p.every(Number.isFinite)?p:null;}
function summary(){const byStatus={};for(const o of state.occurrences)byStatus[o.status]=(byStatus[o.status]??0)+1;return {occurrences:state.occurrences.length,workOrders:state.workOrders.length,evidence:state.evidence.length,byStatus,websocketClients:wsClients.size,eventCount:state.events.length};}
function territoryFor(lon,lat){const n=nearestStreet(operationalFeatures,lon,lat,120);if(!n)return {matched:false};const p=n.feature.properties;return {matched:true,streetSegmentSourceIndex:p._source_index??null,streetName:p.nom_novo??p.logradouro??null,streetType:p.tipo_log??null,cep:p.cep??null,neighborhood:p.bairro??null,zone:p.Zona??null,distanceM:Number(n.distanceM.toFixed(3)),source:'Logradouros 2025'};}
function getOccurrence(id){return state.occurrences.find(o=>o.id===id);}
function getWorkOrder(id){return state.workOrders.find(w=>w.id===id);}
function evidenceForOccurrence(id){return state.evidence.filter(e=>e.occurrenceId===id);}
function corroborationCount(o){const d=duplicateCandidates(state.occurrences.filter(x=>x.id!==o.id),o,{radiusM:35,windowHours:24});return d.length;}
function recomputeICI(o,e,user){const ici=assessICI({occurrence:o,evidence:e,user,corroborationCount:corroborationCount(o),authorityValidated:Boolean(e.authorityValidated)});e.ici=ici;o.ici=ici;o.updatedAt=new Date().toISOString();return ici;}

function createEvidence(o,b,user){
  if(!canUploadEvidence(user,o))throw new Error('forbidden');
  const mediaType=String(b.mediaType??'').toLowerCase();
  if(!ALLOWED_MEDIA_TYPES.has(mediaType))throw new Error('unsupported_media_type');
  const buffer=decodeEvidenceBase64(b.dataBase64,{maxBytes:8*1024*1024});
  const digest=sha256(buffer),ext=extensionForMediaType(mediaType),dir=path.join(evidenceRoot,digest.slice(0,2));fs.mkdirSync(dir,{recursive:true});
  const localPath=path.join(dir,`${digest}${ext}`);if(!fs.existsSync(localPath))fs.writeFileSync(localPath,buffer,{flag:'wx'});
  const lat=b.latitude==null?null:Number(b.latitude),lon=b.longitude==null?null:Number(b.longitude);
  if((lat!=null&&!Number.isFinite(lat))||(lon!=null&&!Number.isFinite(lon)))throw new Error('invalid_evidence_coordinates');
  const e={id:crypto.randomUUID(),occurrenceId:o.id,originalFilename:sanitizeFilename(b.filename??`evidence${ext}`),mediaType,byteLength:buffer.length,sha256:digest,hashVerified:sha256(fs.readFileSync(localPath))===digest,objectKey:path.relative(root,localPath).replaceAll('\\','/'),capturedAt:b.capturedAt??null,latitude:lat,longitude:lon,uploadedBy:user.id,authorityValidated:false,validatedBy:null,createdAt:new Date().toISOString()};
  recomputeICI(o,e,user);state.evidence.push(e);o.evidenceState='EVIDENCE_VALIDATED';event('evidence.created','evidence',e.id,{occurrenceId:o.id,sha256:e.sha256,byteLength:e.byteLength,ici:e.ici});return e;
}

const panelDir=path.join(root,'apps/panel-gis-proof');
const citizenDir=path.join(root,'apps/citizen-web-proof');
const server=http.createServer(async(req,res)=>{
  const u=new URL(req.url||'/',`http://${HOST}:${PORT}`);
  if(req.method==='OPTIONS'){res.writeHead(204,corsHeaders());return res.end();}
  try{
    if(req.method==='GET'&&u.pathname==='/health')return send(res,200,{status:'ok',service:'urbis-local-probe',version:VERSION,street_features:operationalFeatures.length,auth:'RBAC-HS256-local-proof',storage:'content-addressed-local-proof',...summary()});

    if(req.method==='POST'&&u.pathname==='/v1/auth/login'){
      const b=await bodyJson(req),email=normalizeEmail(b.email),user=state.users.find(x=>x.email===email);
      if(!user||!verifyPassword(String(b.password??''),user.passwordHash))return send(res,401,{error:'invalid_credentials'});
      const accessToken=issueAccessToken(user,{secret:TOKEN_SECRET,ttlSeconds:3600});return send(res,200,{accessToken,tokenType:'Bearer',expiresIn:3600,user:redactUser(user)});
    }
    if(req.method==='POST'&&u.pathname==='/v1/auth/register'){
      const b=await bodyJson(req),email=normalizeEmail(b.email);if(state.users.some(x=>x.email===email))return send(res,409,{error:'email_already_exists'});
      const user={id:crypto.randomUUID(),email,displayName:String(b.displayName??'Cidadão').trim().slice(0,120)||'Cidadão',roles:['CITIZEN'],passwordHash:hashPassword(b.password),active:true,createdAt:new Date().toISOString()};state.users.push(user);
      const accessToken=issueAccessToken(user,{secret:TOKEN_SECRET,ttlSeconds:3600});return send(res,201,{accessToken,tokenType:'Bearer',expiresIn:3600,user:redactUser(user)});
    }
    if(req.method==='GET'&&u.pathname==='/v1/auth/me'){const user=currentUser(req);if(!user)return send(res,401,{error:'authentication_required'});return send(res,200,user);}

    if(req.method==='GET'&&u.pathname==='/v1/operations/summary'){authorized(req,'operations:read');return send(res,200,summary());}
    if(req.method==='GET'&&u.pathname==='/v1/territory/stats')return send(res,200,streetMeta);
    const cm=u.pathname.match(/^\/v1\/territory\/cep\/(\d{5}-?\d{3})$/);
    if(req.method==='GET'&&cm){const cep=cm[1].includes('-')?cm[1]:cm[1].slice(0,5)+'-'+cm[1].slice(5);const rows=cepIndex.get(cep)||[];return send(res,rows.length?200:404,{cep,count:rows.length,records:rows});}
    if(req.method==='GET'&&u.pathname==='/v1/territory/streets'){const bbox=parseBbox(u.searchParams.get('bbox')),limit=Math.max(1,Math.min(Number(u.searchParams.get('limit')||500),5000)),bairro=(u.searchParams.get('bairro')||'').toLowerCase(),zone=(u.searchParams.get('zone')||'').toLowerCase();const arr=features.filter(({ft,bbox:fb})=>(!bbox||intersects(fb,bbox))&&(!bairro||String(ft.properties.bairro||'').toLowerCase()===bairro)&&(!zone||String(ft.properties.Zona||'').toLowerCase()===zone)).slice(0,limit).map(x=>x.ft);return send(res,200,{type:'FeatureCollection',count:arr.length,features:arr});}
    if(req.method==='GET'&&u.pathname==='/v1/territory/nearest'){const lat=Number(u.searchParams.get('lat')),lon=Number(u.searchParams.get('lon'));if(!Number.isFinite(lat)||!Number.isFinite(lon))return send(res,400,{error:'lat_lon_required'});const n=nearestStreet(operationalFeatures,lon,lat,120);return send(res,200,{query:{lat,lon},result:n?{distance_m:n.distanceM,properties:n.feature.properties}:null});}
    if(req.method==='POST'&&u.pathname==='/v1/resilience/evaluate'){const b=await bodyJson(req);return send(res,200,evaluateResilience(b));}

    if(req.method==='GET'&&u.pathname==='/v1/occurrences'){
      authorized(req,'occurrence:read:any');let records=[...state.occurrences].sort((a,b)=>Date.parse(b.createdAt)-Date.parse(a.createdAt));const status=u.searchParams.get('status'),cat=u.searchParams.get('categoryCode');if(status)records=records.filter(o=>o.status===status.toUpperCase());if(cat)records=records.filter(o=>o.categoryCode===cat.toUpperCase());return send(res,200,{count:records.length,records});
    }
    if(req.method==='GET'&&u.pathname==='/v1/me/occurrences'){
      const user=authorized(req,'occurrence:read:self');const records=state.occurrences.filter(o=>o.reporterUserId===user.id).sort((a,b)=>Date.parse(b.createdAt)-Date.parse(a.createdAt));return send(res,200,{count:records.length,records});
    }
    if(req.method==='POST'&&u.pathname==='/v1/occurrences'){
      const user=authorized(req,'occurrence:create');const b=await bodyJson(req);
      if(b.clientRequestId){const prior=state.occurrences.find(o=>o.clientRequestId===b.clientRequestId&&o.reporterUserId===user.id);if(prior)return send(res,200,{occurrence:prior,duplicates:[],idempotent:true});}
      const territory=territoryFor(Number(b.longitude),Number(b.latitude));const built=buildOccurrence(b,{protocol:protocol(),territory,existing:state.occurrences});built.occurrence.clientRequestId=b.clientRequestId??null;built.occurrence.reporterUserId=user.id;built.occurrence.reporter={id:user.id,displayName:user.displayName};if(territory.matched)built.occurrence.evidenceState='GEO_VALIDATED';state.occurrences.push(built.occurrence);event('occurrence.created','occurrence',built.occurrence.id,{...built,reporter:{id:user.id}});return send(res,201,{...built,idempotent:false});
    }
    const om=u.pathname.match(/^\/v1\/occurrences\/([0-9a-f-]+)$/i);
    if(req.method==='GET'&&om){const user=currentUser(req);if(!user)return send(res,401,{error:'authentication_required'});const o=getOccurrence(om[1]);if(!o)return send(res,404,{error:'occurrence_not_found'});if(!canReadOccurrence(user,o))return send(res,403,{error:'forbidden'});return send(res,200,{...o,evidence:evidenceForOccurrence(o.id),workOrders:hasPermission(user,'work_order:read')||hasPermission(user,'operations:read')?state.workOrders.filter(w=>w.occurrenceId===o.id):[]});}

    const em=u.pathname.match(/^\/v1\/occurrences\/([0-9a-f-]+)\/evidence$/i);
    if(req.method==='GET'&&em){const user=currentUser(req);if(!user)return send(res,401,{error:'authentication_required'});const o=getOccurrence(em[1]);if(!o)return send(res,404,{error:'occurrence_not_found'});if(!canReadOccurrence(user,o)&&!hasPermission(user,'evidence:read:any'))return send(res,403,{error:'forbidden'});return send(res,200,{count:evidenceForOccurrence(o.id).length,records:evidenceForOccurrence(o.id)});}
    if(req.method==='POST'&&em){const user=currentUser(req);if(!user)return send(res,401,{error:'authentication_required'});const o=getOccurrence(em[1]);if(!o)return send(res,404,{error:'occurrence_not_found'});const b=await bodyJson(req),e=createEvidence(o,b,user);return send(res,201,{evidence:e,occurrence:{id:o.id,protocol:o.protocol,evidenceState:o.evidenceState,ici:o.ici}});}

    const evm=u.pathname.match(/^\/v1\/occurrences\/([0-9a-f-]+)\/evidence\/([0-9a-f-]+)\/authority-validate$/i);
    if(req.method==='POST'&&evm){const user=authorized(req,'evidence:validate'),o=getOccurrence(evm[1]);if(!o)return send(res,404,{error:'occurrence_not_found'});const e=state.evidence.find(x=>x.id===evm[2]&&x.occurrenceId===o.id);if(!e)return send(res,404,{error:'evidence_not_found'});e.authorityValidated=true;e.validatedBy=user.id;e.validatedAt=new Date().toISOString();const ici=recomputeICI(o,e,user);o.evidenceState='AUTHORITY_VALIDATED';event('evidence.authority_validated','evidence',e.id,{occurrenceId:o.id,validatedBy:user.id,ici});return send(res,200,{evidence:e,occurrence:{id:o.id,evidenceState:o.evidenceState,ici}});}

    const im=u.pathname.match(/^\/v1\/occurrences\/([0-9a-f-]+)\/ici$/i);
    if(req.method==='GET'&&im){const user=currentUser(req);if(!user)return send(res,401,{error:'authentication_required'});const o=getOccurrence(im[1]);if(!o)return send(res,404,{error:'occurrence_not_found'});if(!canReadOccurrence(user,o)&&!hasPermission(user,'evidence:read:any'))return send(res,403,{error:'forbidden'});return send(res,200,{occurrenceId:o.id,protocol:o.protocol,ici:o.ici??null,evidenceState:o.evidenceState,notice:'ICI-URBIS alpha is an engineering confidence indicator, not proof of truth or authenticity.'});}

    const tm=u.pathname.match(/^\/v1\/occurrences\/([0-9a-f-]+)\/triage$/i);
    if(req.method==='POST'&&tm){authorized(req,'occurrence:triage');const o=getOccurrence(tm[1]);if(!o)return send(res,404,{error:'occurrence_not_found'});const b=await bodyJson(req);const duplicateOf=b.duplicateOf??(String(b.decision).toUpperCase()==='DUPLICATE'?state.occurrences.find(x=>x.id!==o.id&&x.categoryCode===o.categoryCode)?.id:null);const out=triageOccurrence(o,b.decision,{duplicateOf,notes:b.notes});Object.assign(o,out.occurrence);if(out.workOrder)state.workOrders.push(out.workOrder);event('occurrence.triaged','occurrence',o.id,{occurrence:o,workOrder:out.workOrder});return send(res,200,{occurrence:o,workOrder:out.workOrder});}

    if(req.method==='GET'&&u.pathname==='/v1/work-orders'){const user=currentUser(req);if(!user||(!hasPermission(user,'work_order:read')&&!hasPermission(user,'operations:read')))return send(res,user?403:401,{error:user?'forbidden':'authentication_required'});return send(res,200,{count:state.workOrders.length,records:[...state.workOrders].reverse()});}
    const wm=u.pathname.match(/^\/v1\/work-orders\/([0-9a-f-]+)\/status$/i);
    if(req.method==='POST'&&wm){authorized(req,'work_order:update');const w=getWorkOrder(wm[1]);if(!w)return send(res,404,{error:'work_order_not_found'});const o=getOccurrence(w.occurrenceId);const b=await bodyJson(req);const out=advanceWorkOrder(w,o,b.status,{result:b.result??null});Object.assign(w,out.workOrder);Object.assign(o,out.occurrence);event('work_order.status','work_order',w.id,{workOrder:w,occurrence:o});return send(res,200,{workOrder:w,occurrence:o});}

    if(req.method==='GET'&&(u.pathname==='/'||u.pathname==='/panel'||u.pathname==='/panel/'))return sendFile(res,path.join(panelDir,'index.html'),'text/html; charset=utf-8');
    if(req.method==='GET'&&u.pathname==='/panel/app.js')return sendFile(res,path.join(panelDir,'app.js'),'text/javascript; charset=utf-8');
    if(req.method==='GET'&&u.pathname==='/panel/styles.css')return sendFile(res,path.join(panelDir,'styles.css'),'text/css; charset=utf-8');
    if(req.method==='GET'&&(u.pathname==='/citizen'||u.pathname==='/citizen/'))return sendFile(res,path.join(citizenDir,'index.html'),'text/html; charset=utf-8');
    if(req.method==='GET'&&u.pathname==='/citizen/app.js')return sendFile(res,path.join(citizenDir,'app.js'),'text/javascript; charset=utf-8');
    if(req.method==='GET'&&u.pathname==='/citizen/styles.css')return sendFile(res,path.join(citizenDir,'styles.css'),'text/css; charset=utf-8');
    if(req.method==='GET'&&u.pathname==='/assets/urbis-logo.png')return sendFile(res,path.join(root,'assets/source/URBIS.png'),'image/png');
    if(req.method==='GET'&&u.pathname==='/data/streets.geojson')return sendFile(res,streetsPath,'application/geo+json; charset=utf-8');
    return send(res,404,{error:'not_found'});
  }catch(e){const msg=String(e?.message??e);const code=msg==='authentication_required'?401:msg==='forbidden'?403:400;return send(res,code,{error:msg});}
});

function wsFrame(text){const p=Buffer.from(text);if(p.length<126)return Buffer.concat([Buffer.from([0x81,p.length]),p]);if(p.length<65536){const h=Buffer.alloc(4);h[0]=0x81;h[1]=126;h.writeUInt16BE(p.length,2);return Buffer.concat([h,p]);}const h=Buffer.alloc(10);h[0]=0x81;h[1]=127;h.writeBigUInt64BE(BigInt(p.length),2);return Buffer.concat([h,p]);}
function sendWs(socket,text){try{socket.write(wsFrame(text));}catch{wsClients.delete(socket);}}
server.on('upgrade',(req,socket)=>{
  const u=new URL(req.url||'/',`http://${HOST}:${PORT}`);if(u.pathname!=='/ws/occurrences'){socket.destroy();return;}
  try{const token=u.searchParams.get('access_token');const claims=verifyAccessToken(token,{secret:TOKEN_SECRET});if(!hasPermission(claims,'operations:read'))throw new Error('forbidden');}catch{socket.write('HTTP/1.1 401 Unauthorized\r\nConnection: close\r\n\r\n');socket.destroy();return;}
  const key=req.headers['sec-websocket-key'];if(!key){socket.destroy();return;}const accept=crypto.createHash('sha1').update(key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+accept+'\r\n\r\n');wsClients.add(socket);sendWs(socket,JSON.stringify({topic:'connection.ready',entityType:'system',entityId:'local-probe',payload:{version:VERSION},at:new Date().toISOString()}));socket.on('close',()=>wsClients.delete(socket));socket.on('error',()=>wsClients.delete(socket));socket.on('end',()=>wsClients.delete(socket));
});

server.listen(PORT,HOST,()=>{
  console.log(`URBIS v${VERSION} painel: http://${HOST}:${PORT}/panel/`);
  console.log(`URBIS cidadão: http://${HOST}:${PORT}/citizen/`);
  if(LOOPBACK)console.log('Credenciais locais de demonstração: *@urbis.local / '+DEMO_PASSWORD+' (não usar em produção)');
});
function shutdown(){for(const s of wsClients)s.destroy();server.close(()=>process.exit(0));setTimeout(()=>process.exit(0),500).unref();}
process.on('SIGTERM',shutdown);process.on('SIGINT',shutdown);
