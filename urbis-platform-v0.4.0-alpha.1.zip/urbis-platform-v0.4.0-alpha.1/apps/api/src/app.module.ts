import { Module } from '@nestjs/common';
import { HealthController } from './health/health.controller';
import { ResilienceController } from './resilience/resilience.controller';
import { TerritoryController } from './territory/territory.controller';
import { OccurrencesController } from './occurrences/occurrences.controller';
import { OperationsController } from './occurrences/operations.controller';
import { MeController } from './occurrences/me.controller';
import { OccurrencesService } from './occurrences/occurrences.service';
import { WorkOrdersController } from './dispatch/work-orders.controller';
import { WorkOrdersService } from './dispatch/work-orders.service';
import { DatabaseService } from './database/database.service';
import { RealtimeService } from './realtime/realtime.service';
import { RealtimeGateway } from './realtime/realtime.gateway';
import { AuthController } from './auth/auth.controller';
import { AuthService } from './auth/auth.service';
import { AuthGuard } from './auth/auth.guard';
import { RolesGuard } from './auth/roles.guard';
import { EvidenceController } from './evidence/evidence.controller';
import { EvidenceService } from './evidence/evidence.service';
import { ObjectStorageService } from './storage/object-storage.service';

@Module({
  controllers:[HealthController,ResilienceController,TerritoryController,AuthController,OccurrencesController,MeController,OperationsController,WorkOrdersController,EvidenceController],
  providers:[DatabaseService,RealtimeService,RealtimeGateway,AuthService,AuthGuard,RolesGuard,ObjectStorageService,EvidenceService,OccurrencesService,WorkOrdersService]
})
export class AppModule {}
