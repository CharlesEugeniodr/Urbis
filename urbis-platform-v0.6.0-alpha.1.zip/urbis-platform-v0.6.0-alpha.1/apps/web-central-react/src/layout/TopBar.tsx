import React from 'react';
import { useAuth } from '../auth/AuthContext';
export function TopBar(){const {user,logout}=useAuth();return <header className="topbar"><div><strong>Painel Municipal em Tempo Real</strong><small>Central de ocorrências georreferenciadas</small></div><div className="top-actions"><span>{user?.displayName||user?.email||'Operador'}</span><button onClick={logout}>Sair</button></div></header>;}
