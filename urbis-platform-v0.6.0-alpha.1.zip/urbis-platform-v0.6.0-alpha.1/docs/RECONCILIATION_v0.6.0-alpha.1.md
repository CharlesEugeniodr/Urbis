# Reconciliação URBIS v0.6.0-alpha.1

## Baselines
- baseline auditada local/GitHub: `f4273dfd4ca40c412eb5a9a09869f521ea107b4b`;
- evolução GitHub analisada: `88fcb4aa8df4910797b25f2d938dc14c4e4b6394`.

## Princípio
A fusão é aditiva: nenhuma funcionalidade comprovada da v0.5 é removida para acomodar a UI posterior.

## Decisões
1. `core/`, `db/`, `data/`, `infra/` e contratos operacionais da v0.5 permanecem como fundação.
2. O App Cidadão recebe a arquitetura expandida, mas mantém GPS/câmera/evidência reais da baseline.
3. O Painel React passa a normalizar DTOs de modo explícito em vez de supor nomenclatura camelCase.
4. A Central usa endpoints operacionais de Central; endpoints `/v1/field/*` permanecem exclusivos de equipe de campo.
5. O realtime da Central usa WebSocket nativo, compatível com o backend NestJS `ws`.
6. Métricas e auditoria não podem conter valores demonstrativos fixos.
7. CVE crítica é bloqueio de release; o pacote afetado é atualizado, não ignorado.

## Estado epistêmico
- Implementação local: presente nesta árvore.
- Build Flutter: pendente neste ambiente por ausência do Flutter SDK.
- Build web/NestJS: depende de instalação das dependências.
- Infraestrutura externa: não declarada como homologada sem execução real.
