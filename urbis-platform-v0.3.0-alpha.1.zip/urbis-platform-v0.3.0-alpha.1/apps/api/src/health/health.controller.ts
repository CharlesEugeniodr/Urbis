import { Controller, Get } from '@nestjs/common';
@Controller('v1/health')
export class HealthController { @Get() get(){ return {status:'ok',service:'urbis-api',version:'0.2.0-alpha.1'}; } }
