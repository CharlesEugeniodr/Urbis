import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import fs from 'node:fs';

const PORT=3217,BASE=`http://127.0.0.1:${PORT}`;
const geo=JSON.parse(fs.readFileSync(new URL('../data/territorial/logradouros_parauapebas_2025.operational.geojson',import.meta.url),'utf8'));
const [lon,lat]=geo.features[0].geometry.coordinates[0][0];
let proc;
async function waitHealth(){for(let i=0;i<80;i++){try{const r=await fetch(BASE+'/health');if(r.ok)return await r.json();}catch{}await new Promise(r=>setTimeout(r,75));}throw new Error('probe_not_ready');}
async function post(url,body){const r=await fetch(BASE+url,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});const j=await r.json();assert.ok(r.ok,JSON.stringify(j));return j;}

test.before(async()=>{proc=spawn(process.execPath,['tools/local-probe-server.mjs'],{cwd:new URL('..',import.meta.url),env:{...process.env,URBIS_PORT:String(PORT)},stdio:['ignore','pipe','pipe']});await waitHealth();});
test.after(async()=>{if(proc&&!proc.killed){proc.kill('SIGTERM');await new Promise(r=>proc.once('exit',r));}});

test('fluxo HTTP completo: ocorrência → duplicidade → triagem → OS → resolução',async()=>{
  const a=await post('/v1/occurrences',{categoryCode:'PAVEMENT',description:'teste operacional A',latitude:lat,longitude:lon,clientRequestId:'e2e-a'});
  assert.match(a.occurrence.protocol,/^URB-\d{8}-\d{7}$/);
  assert.equal(a.occurrence.territory.matched,true);
  const b=await post('/v1/occurrences',{categoryCode:'PAVEMENT',description:'teste operacional B',latitude:lat,longitude:lon+0.00001,clientRequestId:'e2e-b'});
  assert.equal(b.occurrence.duplicateSuspected,true);
  assert.ok(b.duplicates.length>=1);
  const t=await post(`/v1/occurrences/${a.occurrence.id}/triage`,{decision:'PROCEDENT'});
  assert.equal(t.occurrence.status,'DISPATCHED');
  assert.ok(t.workOrder.id);
  const started=await post(`/v1/work-orders/${t.workOrder.id}/status`,{status:'IN_PROGRESS'});
  assert.equal(started.occurrence.status,'IN_SERVICE');
  const done=await post(`/v1/work-orders/${t.workOrder.id}/status`,{status:'COMPLETED',result:{proof:'e2e'}});
  assert.equal(done.occurrence.status,'RESOLVED');
  const list=await fetch(BASE+'/v1/occurrences').then(r=>r.json());
  assert.equal(list.count,2);
});

test('idempotência por clientRequestId impede protocolo duplicado por retry',async()=>{
  const x=await post('/v1/occurrences',{categoryCode:'LIGHTING',latitude:lat,longitude:lon,clientRequestId:'retry-fixed'});
  const y=await post('/v1/occurrences',{categoryCode:'LIGHTING',latitude:lat,longitude:lon,clientRequestId:'retry-fixed'});
  assert.equal(y.idempotent,true);
  assert.equal(x.occurrence.id,y.occurrence.id);
  assert.equal(x.occurrence.protocol,y.occurrence.protocol);
});

test('WebSocket nativo recebe atualização de ocorrência em tempo real',async()=>{
  assert.equal(typeof WebSocket,'function');
  const ws=new WebSocket(`ws://127.0.0.1:${PORT}/ws/occurrences`);
  await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true});});
  const message=new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(new Error('ws_timeout')),3000);ws.addEventListener('message',e=>{const d=JSON.parse(String(e.data));if(d.topic==='occurrence.created'){clearTimeout(timer);resolve(d);}},{once:false});});
  const created=await post('/v1/occurrences',{categoryCode:'WATER',description:'ws test',latitude:lat,longitude:lon,clientRequestId:'ws-event'});
  const e=await message;
  assert.equal(e.entityId,created.occurrence.id);
  ws.close();
});
