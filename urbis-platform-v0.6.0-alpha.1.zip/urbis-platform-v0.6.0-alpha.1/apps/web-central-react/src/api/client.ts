export const API_URL = (import.meta.env.VITE_API_URL as string) || 'http://localhost:3100';

export async function fetchApi(endpoint: string, options: RequestInit = {}) {
  const token = sessionStorage.getItem('urbis_token');
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string> | undefined),
  };
  if (token) headers.Authorization = `Bearer ${token}`;
  const response = await fetch(`${API_URL}${endpoint}`, { ...options, headers });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    if (response.status === 401) {
      sessionStorage.removeItem('urbis_token');
      sessionStorage.removeItem('urbis_user');
      if (window.location.pathname !== '/login') window.location.assign('/login');
    }
    throw new Error(body.message || body.error || `HTTP ${response.status}`);
  }
  return body;
}

export function normalizeOccurrence(raw: any) {
  return {
    ...raw,
    id: raw.id,
    protocol: raw.protocol,
    categoryCode: raw.categoryCode ?? raw.category_code ?? raw.category?.code,
    categoryName: raw.categoryName ?? raw.category_name ?? raw.category?.name,
    latitude: Number(raw.latitude ?? raw.lat),
    longitude: Number(raw.longitude ?? raw.lon),
    addressText: raw.addressText ?? raw.address_text ?? raw.address,
    createdAt: raw.createdAt ?? raw.created_at,
    updatedAt: raw.updatedAt ?? raw.updated_at,
    resolvedAt: raw.resolvedAt ?? raw.resolved_at,
    evidenceState: raw.evidenceState ?? raw.evidence_state,
    territory: raw.territory ?? raw.territory_snapshot ?? {},
    ici: raw.ici ?? raw.iciScore ?? raw.ici_score ?? null,
  };
}
