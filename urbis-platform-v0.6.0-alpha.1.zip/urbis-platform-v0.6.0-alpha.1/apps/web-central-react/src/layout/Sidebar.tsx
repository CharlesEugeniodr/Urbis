import React from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, MapPinned, ListChecks, ClipboardList, FileBarChart, ShieldCheck } from 'lucide-react';
const items=[['/','Dashboard',LayoutDashboard],['/mapa','Mapa GIS',MapPinned],['/ocorrencias','Ocorrências',ListChecks],['/os','Ordens de Serviço',ClipboardList],['/relatorios','Relatórios',FileBarChart],['/auditoria','Auditoria',ShieldCheck]] as const;
export function Sidebar(){return <aside className="sidebar"><div className="brand">URBIS</div>{items.map(([to,label,Icon])=><NavLink key={to} to={to} end={to==='/' }><Icon size={18}/>{label}</NavLink>)}</aside>;}
