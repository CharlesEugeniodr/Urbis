# Arquitetura inicial — URBIS v0.1

## Camadas

```text
App Cidadão (Flutter) ─┐
App Campo (Flutter) ───┼── API Gateway / NestJS ── Serviços de domínio
Painel Interno (React) ┤             │
Painel Público ────────┘             ├── PostgreSQL + PostGIS
                                      ├── Redis/BullMQ
                                      ├── WebSocket/SSE
                                      ├── Object Storage (mídia)
                                      └── integrações externas
```

## Domínios

- Identity & Access
- Occurrence Management
- Evidence & Media
- GIS / Territory
- Dispatch & Work Orders
- Field Operations
- Contracts & Warranty
- Resilience / PLANCON
- Alerts
- Citizen Contribution / Scoring
- Transparency
- Observability & Audit

## Decisões desta versão

### PostgreSQL + PostGIS
É a fonte transacional e geoespacial primária. Geometria é armazenada em SRID 4326 para
interoperabilidade, com possibilidade de projeções locais em consultas analíticas.

### Eventos
Alterações de status geram eventos de domínio. O modelo foi preparado para Redis/BullMQ no MVP
e Kafka em expansão, sem acoplar a regra de negócio a um broker específico.

### Proveniência
Todo dado oficial/dinâmico deve apontar para `data_sources` e, quando aplicável, `source_datasets`.
Eventos de sensor armazenam instante de observação e de ingestão separadamente.

### PLANCON
Regras do PLANCON são dados versionados e não constantes espalhadas no código. O motor lê um
arquivo versionado e registra `rule_version` no resultado.

### Mapa
O PDF urbano anexado é referência cartográfica, não geometria operacional. A camada real deverá
ser importada de GeoJSON/GeoPackage/Shapefile/WFS ou outra fonte vetorial oficial.
