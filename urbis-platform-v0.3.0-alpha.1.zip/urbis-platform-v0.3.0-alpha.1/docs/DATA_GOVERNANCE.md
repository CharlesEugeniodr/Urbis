# Governança de dados

## Classes de evidência

- `CITIZEN_REPORT`: observação submetida por cidadão.
- `FIELD_VALIDATION`: confirmação por equipe/servidor autorizado.
- `OFFICIAL_SENSOR`: medição de sensor oficial/credenciado.
- `OFFICIAL_DATASET`: dado documental ou base oficial versionada.
- `INTEGRATION`: dado recebido de sistema externo autenticado.

## Estados de validação

`RECEIVED → GEO_VALIDATED → EVIDENCE_VALIDATED → CORROBORATED → AUTHORITY_VALIDATED → CLOSED`

Os estados podem regredir mediante auditoria ou ser marcados como `REJECTED`/`DUPLICATE`.

## Regras mínimas

- fonte e versão nunca são apagadas;
- localização do cidadão não é publicada no painel público em granularidade que identifique a pessoa;
- mídia original mantém hash SHA-256;
- alterações relevantes geram trilha em `audit_log`;
- base documental não é promovida a "atual" sem nova versão/fonte.
