# URBIS v0.6.0-alpha.1 — Reconciliação sem regressão

## Origem
Esta versão funde a baseline auditada `v0.5.0-alpha.1` com as evoluções posteriores do repositório GitHub, preservando as funcionalidades comprovadas e eliminando regressões identificadas na análise cruzada.

## Correções P0
- restauração de GPS real no App Cidadão;
- precisão GNSS real enviada à API;
- captura de câmera/evidência no fluxo de registro cidadão;
- protocolo oficial exibido após criação;
- remoção do ponto GPS simulado;
- correção da integração React ↔ API mediante normalização snake_case/camelCase;
- Central passa a consultar `/v1/work-orders` em vez do endpoint reservado a FIELD_AGENT;
- KPI de OS vencidas ligado a `overdueServiceOrders` real;
- MapLibre elevado para `^6.4.1`, eliminando a versão identificada no CI com CVE-2026-85061;
- Socket.IO removido do painel; uso de WebSocket nativo compatível com `/ws/occurrences`;
- auditoria visual conectada a endpoint administrativo real.

## Evoluções preservadas do GitHub
- painel React modular;
- apps Flutter expandidos como direção arquitetural;
- build NestJS/React/Next no CI;
- pipeline de segurança;
- GitHub Pages/landing;
- infraestrutura Docker/Kubernetes/Terraform;
- package-level separation do monorepo.

## Núcleo preservado da v0.5
- motores `core/*`;
- PLANCON e regras de resiliência;
- ICI-URBIS;
- PostGIS, duplicidade e territorialização;
- evidência SHA-256;
- RBAC/LGPD;
- outbox, Redis/Kafka/FCM abstrações;
- relatórios CSV/XLSX/PDF;
- testes locais e datasets auditados.

## Gates
A versão só deverá ser promovida a release de homologação quando:
1. `npm run test:all` estiver verde;
2. NestJS/React/Next compilarem;
3. `flutter analyze && flutter test` estiver verde nos dois apps;
4. Trivy não reportar vulnerabilidade CRITICAL aceita;
5. staging PostGIS/Redis/MinIO/Kafka estiver operacional;
6. k6 comprovar p95 <300 ms no cenário-alvo;
7. WebSocket/SSE comprovar <3 s em staging.
