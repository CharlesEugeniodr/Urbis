import React from 'react';
import { Outlet } from 'react-router-dom';
import { Sidebar } from './Sidebar';
import { TopBar } from './TopBar';
import { useRealtime } from '../realtime/useRealtime';
export function MainLayout(){useRealtime();return <div className="shell"><Sidebar/><div className="main"><TopBar/><main className="content"><Outlet/></main></div></div>;}
