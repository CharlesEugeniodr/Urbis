import { Body, Controller, Get, Param, Post, Query } from '@nestjs/common';
import { OccurrencesService } from './occurrences.service';

@Controller('v1/occurrences')
export class OccurrencesController {
  constructor(private readonly service:OccurrencesService){}
  @Post() create(@Body() body:Record<string,unknown>){return this.service.create(body as any);}
  @Get() list(@Query() query:Record<string,string>){return this.service.list(query);}
  @Get(':id') get(@Param('id') id:string){return this.service.get(id);}
  @Post(':id/triage') triage(@Param('id') id:string,@Body() body:Record<string,unknown>){return this.service.triage(id,body as any);}
}
