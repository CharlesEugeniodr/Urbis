import { OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { WebSocketGateway, WebSocketServer } from '@nestjs/websockets';
import { WebSocket, WebSocketServer as WsServer } from 'ws';
import { AuthService } from '../auth/auth.service';
import { RealtimeService, UrbisRealtimeEvent } from './realtime.service';

@WebSocketGateway({path:'/ws/occurrences'})
export class RealtimeGateway implements OnModuleInit,OnModuleDestroy {
  @WebSocketServer() server!:WsServer;
  private unsubscribe?:()=>void;
  constructor(private readonly realtime:RealtimeService,private readonly auth:AuthService){}
  handleConnection(client:WebSocket,...args:any[]){
    try{
      const req=args[0];const url=new URL(req?.url??'/ws/occurrences','http://urbis.local');const token=url.searchParams.get('access_token')??'';const claims=this.auth.verifyAccessToken(token);const roles=(claims.roles??[]).map((x:string)=>x.toUpperCase());if(!roles.some((r:string)=>['OPERATOR','MANAGER','ADMIN'].includes(r)))throw new Error('forbidden');
    }catch{client.close(1008,'unauthorized');}
  }
  onModuleInit(){
    this.unsubscribe=this.realtime.subscribe((event:UrbisRealtimeEvent)=>{
      const payload=JSON.stringify(event);
      for(const client of this.server?.clients??[]){ if(client.readyState===WebSocket.OPEN) client.send(payload); }
    });
  }
  onModuleDestroy(){this.unsubscribe?.();}
}
