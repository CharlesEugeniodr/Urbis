import { NestFactory } from '@nestjs/core';
import { WsAdapter } from '@nestjs/platform-ws';
import { AppModule } from './app.module';
async function bootstrap(){
  const app=await NestFactory.create(AppModule);
  app.useWebSocketAdapter(new WsAdapter(app));
  const corsOrigin=process.env.URBIS_CORS_ORIGIN;
  app.enableCors(corsOrigin?{origin:corsOrigin.split(',').map(v=>v.trim())}:{origin:false});
  await app.listen(Number(process.env.PORT??3000));
}
bootstrap();
