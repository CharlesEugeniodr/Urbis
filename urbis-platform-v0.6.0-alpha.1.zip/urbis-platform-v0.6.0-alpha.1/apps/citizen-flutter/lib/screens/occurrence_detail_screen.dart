import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/api_client.dart';

class OccurrenceDetailScreen extends StatefulWidget {
  const OccurrenceDetailScreen({super.key, required this.occurrenceId});
  final String occurrenceId;
  @override
  State<OccurrenceDetailScreen> createState() => _OccurrenceDetailScreenState();
}

class _OccurrenceDetailScreenState extends State<OccurrenceDetailScreen> {
  late Future<Map<String, dynamic>> future;
  @override
  void didChangeDependencies() { super.didChangeDependencies(); future = context.read<ApiClient>().request('/v1/occurrences/${widget.occurrenceId}'); }
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Detalhe da ocorrência')),
        body: FutureBuilder<Map<String, dynamic>>(
          future: future,
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
            if (snapshot.hasError) return Center(child: Text(snapshot.error.toString()));
            final o = snapshot.data ?? {};
            return ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Text(o['protocol']?.toString() ?? widget.occurrenceId, style: Theme.of(context).textTheme.headlineSmall),
                const SizedBox(height: 10),
                Text('Status: ${o['status'] ?? '-'}'),
                Text('Categoria: ${o['category_code'] ?? o['categoryCode'] ?? '-'}'),
                Text('Descrição: ${o['description'] ?? '-'}'),
                Text('Endereço: ${o['address_text'] ?? o['addressText'] ?? '-'}'),
                Text('CEP: ${o['cep'] ?? '-'}'),
                Text('Criada em: ${o['created_at'] ?? o['createdAt'] ?? '-'}'),
              ],
            );
          },
        ),
      );
}
