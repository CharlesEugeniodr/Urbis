import { Body, Controller, Post } from '@nestjs/common';
// O motor definitivo deve ser registrado como provider e carregar o ruleset do banco.
@Controller('v1/resilience')
export class ResilienceController {
  @Post('evaluate')
  evaluate(@Body() body: Record<string,unknown>){
    return {accepted:true,input:body,note:'Conectar ao provider ResilienceRulesetService; lógica validada em /core/risk-engine.mjs'};
  }
}
