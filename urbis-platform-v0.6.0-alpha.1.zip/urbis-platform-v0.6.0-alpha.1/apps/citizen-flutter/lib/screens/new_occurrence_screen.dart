import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import '../core/api_client.dart';
import '../widgets/category_selector.dart';

class NewOccurrenceScreen extends StatefulWidget {
  const NewOccurrenceScreen({super.key});
  @override
  State<NewOccurrenceScreen> createState() => _NewOccurrenceScreenState();
}

class _NewOccurrenceScreenState extends State<NewOccurrenceScreen> {
  String? category;
  final description = TextEditingController();
  Position? position;
  XFile? evidence;
  bool busy = false;
  String? status;

  Future<void> locate() async {
    setState(() => busy = true);
    try {
      final p = await context.read<ApiClient>().locate();
      setState(() {
        position = p;
        status = 'GPS capturado: ${p.latitude.toStringAsFixed(6)}, ${p.longitude.toStringAsFixed(6)} • ±${p.accuracy.toStringAsFixed(0)} m';
      });
    } catch (e) {
      setState(() => status = e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> camera() async {
    final file = await ImagePicker().pickImage(source: ImageSource.camera, imageQuality: 90);
    if (file != null) setState(() { evidence = file; status = 'Evidência capturada: ${file.name}'; });
  }

  Future<void> submit() async {
    if (category == null || description.text.trim().isEmpty) {
      setState(() => status = 'Informe a categoria e a descrição.');
      return;
    }
    if (position == null) {
      setState(() => status = 'Capture o GPS antes de registrar.');
      return;
    }
    setState(() => busy = true);
    try {
      final api = context.read<ApiClient>();
      final created = await api.createOccurrence(categoryCode: category!, description: description.text, position: position!);
      final occurrence = Map<String, dynamic>.from(created['occurrence'] ?? {});
      if (evidence != null) {
        await api.uploadEvidence(occurrenceId: occurrence['id'] as String, file: evidence!, position: position!);
      }
      if (!mounted) return;
      await showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Ocorrência registrada'),
          content: Text('Protocolo: ${occurrence['protocol'] ?? occurrence['id']}'),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
        ),
      );
      setState(() {
        category = null;
        description.clear();
        evidence = null;
        position = null;
        status = null;
      });
    } catch (e) {
      setState(() => status = e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final point = position == null ? null : LatLng(position!.latitude, position!.longitude);
    return Scaffold(
      appBar: AppBar(title: const Text('Nova ocorrência')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Categoria', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          CategorySelector(selected: category, onSelect: (value) => setState(() => category = value)),
          const SizedBox(height: 16),
          TextField(controller: description, maxLines: 4, decoration: const InputDecoration(labelText: 'Descrição do problema')),
          const SizedBox(height: 14),
          OutlinedButton.icon(onPressed: busy ? null : locate, icon: const Icon(Icons.my_location), label: const Text('Capturar GPS real')),
          if (point != null) ...[
            const SizedBox(height: 10),
            SizedBox(
              height: 190,
              child: FlutterMap(
                options: MapOptions(initialCenter: point, initialZoom: 17),
                children: [
                  TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'br.com.sigma.urbis.citizen'),
                  MarkerLayer(markers: [Marker(point: point, width: 56, height: 56, child: const Icon(Icons.location_pin, size: 48, color: Colors.red))]),
                ],
              ),
            ),
          ],
          const SizedBox(height: 10),
          OutlinedButton.icon(onPressed: busy ? null : camera, icon: const Icon(Icons.camera_alt_outlined), label: Text(evidence == null ? 'Fotografar evidência' : 'Trocar evidência')),
          if (evidence != null) Padding(padding: const EdgeInsets.only(top: 6), child: Text(evidence!.name)),
          if (status != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(status!)),
          const SizedBox(height: 16),
          FilledButton.icon(onPressed: busy ? null : submit, icon: const Icon(Icons.send), label: Text(busy ? 'Enviando...' : 'Registrar ocorrência')),
          const SizedBox(height: 16),
          const Text('O URBIS envia as coordenadas e a precisão fornecidas pelo dispositivo. A localização não é simulada.', style: TextStyle(fontSize: 11, color: Colors.black54)),
        ],
      ),
    );
  }
}
