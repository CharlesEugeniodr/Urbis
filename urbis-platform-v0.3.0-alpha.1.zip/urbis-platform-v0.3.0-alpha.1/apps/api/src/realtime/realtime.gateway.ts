import { OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { WebSocketGateway, WebSocketServer } from '@nestjs/websockets';
import { WebSocket, WebSocketServer as WsServer } from 'ws';
import { RealtimeService, UrbisRealtimeEvent } from './realtime.service';

@WebSocketGateway({path:'/ws/occurrences'})
export class RealtimeGateway implements OnModuleInit,OnModuleDestroy {
  @WebSocketServer() server!:WsServer;
  private unsubscribe?:()=>void;
  constructor(private readonly realtime:RealtimeService){}
  onModuleInit(){
    this.unsubscribe=this.realtime.subscribe((event:UrbisRealtimeEvent)=>{
      const payload=JSON.stringify(event);
      for(const client of this.server?.clients??[]){ if(client.readyState===WebSocket.OPEN) client.send(payload); }
    });
  }
  onModuleDestroy(){this.unsubscribe?.();}
}
