import { Controller, Get } from '@nestjs/common';
import { OccurrencesService } from './occurrences.service';
@Controller('v1/operations')
export class OperationsController {
  constructor(private readonly service:OccurrencesService){}
  @Get('summary') summary(){return this.service.summary();}
}
