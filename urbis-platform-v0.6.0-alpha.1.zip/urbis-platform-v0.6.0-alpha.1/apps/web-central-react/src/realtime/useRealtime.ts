import { useEffect } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { API_URL } from '../api/client';

export function useRealtime() {
  const queryClient = useQueryClient();
  useEffect(() => {
    const token = sessionStorage.getItem('urbis_token');
    if (!token) return;
    const wsBase = API_URL.replace(/^http:/, 'ws:').replace(/^https:/, 'wss:');
    let ws: WebSocket | undefined;
    let timer: number | undefined;
    let stopped = false;
    const connect = () => {
      if (stopped) return;
      ws = new WebSocket(`${wsBase}/ws/occurrences?access_token=${encodeURIComponent(token)}`);
      ws.onmessage = () => {
        queryClient.invalidateQueries({ queryKey: ['occurrences'] });
        queryClient.invalidateQueries({ queryKey: ['occurrences-map'] });
        queryClient.invalidateQueries({ queryKey: ['dashboard'] });
        queryClient.invalidateQueries({ queryKey: ['work-orders'] });
      };
      ws.onclose = () => { if (!stopped) timer = window.setTimeout(connect, 2000); };
    };
    connect();
    return () => { stopped = true; if (timer) clearTimeout(timer); ws?.close(); };
  }, [queryClient]);
}
