import React from 'react';
import { Link } from 'react-router-dom';
import { useOccurrences } from '../api/hooks';
import { PriorityBadge } from '../components/PriorityBadge';
import { StatusBadge } from '../components/StatusBadge';
export function IncidentListPage(){const {data,isLoading}=useOccurrences(500);if(isLoading)return <p>Carregando...</p>;return <div className="card"><h3>Ocorrências</h3><table><thead><tr><th>Protocolo</th><th>Categoria</th><th>Prioridade</th><th>Status</th><th>Bairro</th><th></th></tr></thead><tbody>{data?.records?.map((o:any)=><tr key={o.id}><td>{o.protocol}</td><td>{o.categoryCode}</td><td><PriorityBadge priority={o.priority}/></td><td><StatusBadge status={o.status}/></td><td>{o.territory?.neighborhood??'—'}</td><td><Link to={`/ocorrencias/${o.id}`}>Abrir</Link></td></tr>)}</tbody></table></div>}
