import React, { createContext, useContext, useState } from 'react';

type User = { id?: string; sub?: string; email?: string; displayName?: string; roles?: string[] } | null;
type AuthValue = { token: string | null; user: User; login: (token: string, user: User) => void; logout: () => void };
const AuthContext = createContext<AuthValue | null>(null);
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [token, setToken] = useState<string | null>(() => sessionStorage.getItem('urbis_token'));
  const [user, setUser] = useState<User>(() => {
    try { return JSON.parse(sessionStorage.getItem('urbis_user') || 'null'); } catch { return null; }
  });
  const login = (value: string, nextUser: User) => {
    sessionStorage.setItem('urbis_token', value);
    sessionStorage.setItem('urbis_user', JSON.stringify(nextUser));
    setToken(value); setUser(nextUser);
  };
  const logout = () => {
    sessionStorage.removeItem('urbis_token'); sessionStorage.removeItem('urbis_user');
    setToken(null); setUser(null);
  };
  return <AuthContext.Provider value={{ token, user, login, logout }}>{children}</AuthContext.Provider>;
}
export function useAuth() { const value = useContext(AuthContext); if (!value) throw new Error('AuthProvider ausente'); return value; }
