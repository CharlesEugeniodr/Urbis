@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo [URBIS] Node.js 20+ nao foi encontrado no PATH.
  pause
  exit /b 1
)
echo [URBIS] Iniciando nucleo operacional local...
start "URBIS Operational Server" cmd /k "cd /d ""%~dp0"" && node tools\local-probe-server.mjs"
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:3100/panel/"
echo [URBIS] Painel operacional aberto. O servidor permanece na janela "URBIS Operational Server".
endlocal
