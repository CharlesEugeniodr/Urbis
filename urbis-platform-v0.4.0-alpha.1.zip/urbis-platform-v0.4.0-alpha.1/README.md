# URBIS

**Cidades Inteligentes, Pessoas Ativas**  
**Você informa. A cidade evolui.**  
**Uma cidade melhor começa com você.**

Produto de propriedade de **Sigma SIHF Soluções Analíticas S/A — CNPJ 01.851.824/0001-38**.

## v0.4.0-alpha.1 — identidade, evidência e aplicativo cidadão

Esta versão acrescenta uma camada de identidade/RBAC e cadeia técnica de evidência ao núcleo operacional v0.3.

Fluxo executável da prova local:

`login → GPS → ocorrência → protocolo → associação territorial → foto/vídeo → SHA-256 → ICI-URBIS → triagem → ordem de serviço → atendimento → resolução → WebSocket`

A malha territorial permanece baseada nos **10.997 segmentos válidos** de `Logradouros 2025 2.geojson`; **82 registros permanecem em quarentena** sem correção silenciosa.

## Executar no Windows

### Central operacional

Dê duplo clique em:

`START_URBIS_PANEL.bat`

Abre: `http://127.0.0.1:3100/panel/`

Credencial **somente para prova local**:

- `manager@urbis.local`
- `UrbisLocal!2026`

### Aplicativo cidadão web de prova

Dê duplo clique em:

`START_URBIS_CITIZEN.bat`

Abre: `http://127.0.0.1:3100/citizen/`

Credencial **somente para prova local**:

- `citizen@urbis.local`
- `UrbisLocal!2026`

O servidor local escuta `127.0.0.1` por padrão. As credenciais acima não devem ser reutilizadas nem expostas em implantação real.

## Identidade e RBAC

Papéis implementados:

- `CITIZEN`
- `OPERATOR`
- `FIELD_AGENT`
- `MANAGER`
- `ADMIN`

A prova local usa senha derivada com **scrypt** e token compacto **HS256**. A API NestJS possui o mesmo modelo de autorização e exige `URBIS_TOKEN_SECRET` forte. Para implantação institucional, o desenho continua compatível com OIDC/Keycloak; a autenticação local não deve ser tratada como substituta de uma federação de identidade governamental.

## Evidência

Endpoint principal:

`POST /v1/occurrences/:id/evidence`

Aceita JPEG, PNG, WebP e MP4, com limite de 8 MB no alpha. O arquivo é armazenado por conteúdo:

`sha256/<prefixo>/<hash>.<ext>`

O SHA-256 comprova a integridade do objeto armazenado em relação aos bytes recebidos. **Não comprova, sozinho, que a cena é verdadeira, que foi capturada no local informado ou que não foi manipulada antes do envio.**

A API inclui abstração de armazenamento:

- `LOCAL` — filesystem;
- `S3` — S3/MinIO compatível.

O `docker-compose.yml` provisiona PostGIS, Redis e MinIO, incluindo criação do bucket privado `urbis-evidence`.

## ICI-URBIS

O **Índice de Confiabilidade da Informação** foi implementado como indicador interno de engenharia, versão `ICI-URBIS-alpha.1`.

Pesos do alpha:

- fonte: 25%;
- consistência geográfica: 20%;
- completude técnica da evidência: 20%;
- consistência temporal: 15%;
- corroboração: 10%;
- validação por autoridade: 10%.

O ICI **não é prova jurídica, perícia, autenticação forense ou declaração automática de veracidade**. Os pesos são parâmetros de engenharia do alpha e devem ser calibrados/validados antes de uso decisório oficial.

## Tempo real multi-instância

A API NestJS mantém o WebSocket `/ws/occurrences` e agora pode usar Redis Pub/Sub (`REDIS_URL`) como ponte entre múltiplas instâncias. O canal usado é `urbis:realtime`.

A conexão WebSocket operacional exige token com papel de Central (`OPERATOR`, `MANAGER` ou `ADMIN`).

## Aplicativo Flutter

`apps/citizen-flutter/` contém o starter funcional do app móvel:

`login → GPS → câmera → registro → evidência → protocolo/ICI`

O Flutter SDK não existe no runtime usado para construir este pacote, portanto o app **não foi compilado nesta entrega**. O código e o `pubspec.yaml` estão prontos para `flutter pub get` e build em ambiente Flutter.

## API principal

- `POST /v1/auth/register`
- `POST /v1/auth/login`
- `GET /v1/auth/me`
- `GET /v1/me/occurrences`
- `POST /v1/occurrences`
- `GET /v1/occurrences`
- `GET /v1/occurrences/:id`
- `POST /v1/occurrences/:id/evidence`
- `GET /v1/occurrences/:id/evidence`
- `GET /v1/occurrences/:id/ici`
- `POST /v1/occurrences/:id/evidence/:mediaId/authority-validate`
- `POST /v1/occurrences/:id/triage`
- `GET /v1/work-orders`
- `POST /v1/work-orders/:id/status`
- `GET /v1/operations/summary`
- `GET /v1/territory/stats`
- `GET /v1/territory/cep/:cep`
- `GET /v1/territory/nearest?lat=...&lon=...`
- `POST /v1/resilience/evaluate`
- WebSocket `/ws/occurrences?access_token=...`

## PostgreSQL/PostGIS

A migration `010_identity_evidence_ici.sql` acrescenta:

- identidades locais/provedores;
- papéis RBAC;
- metadados técnicos de mídia;
- validação por autoridade;
- avaliações ICI versionadas;
- campos ICI no registro da ocorrência;
- auditoria de autenticação.

Em ambiente com Docker:

```bash
cd infra
docker compose up -d
```

As migrations são aplicadas apenas na criação de um volume PostgreSQL novo. Em banco já existente, utilize um mecanismo formal de migrations; não dependa do `docker-entrypoint-initdb.d` para upgrades.

## Testes

```bash
npm run test:all
```

A v0.4 contém **23 testes automatizados**, todos executados na construção desta entrega:

- 6 PLANCON;
- 4 integridade territorial;
- 4 núcleo operacional;
- 5 identidade/evidência/ICI;
- 4 E2E autenticados, incluindo RBAC, SHA-256, validação por autoridade e WebSocket.

A validação de datasets permanece separada e também foi executada.

## Limites atuais

- o PostGIS/Redis/MinIO não foram inicializados neste runtime, pois Docker/PostgreSQL não estão disponíveis aqui;
- o E2E desta versão usa o servidor local de prova em memória e armazenamento local por conteúdo;
- o aplicativo Flutter foi escrito, mas não compilado no runtime desta construção;
- o módulo de OIDC/Keycloak ainda não substitui a identidade local;
- extração/verificação forense de EXIF, assinatura de captura e attestation do dispositivo ainda não estão implementadas;
- geometrias vetoriais de setores de risco, manchas de inundação, abrigos e rotas de evacuação continuam pendentes de fontes vetoriais oficiais;
- regras de competência administrativa e SLAs devem ser parametrizadas com atos, contratos e órgãos vigentes na implantação.

Consulte `docs/IDENTITY_EVIDENCE.md`, `docs/OPERATIONAL_CORE.md` e `docs/IMPLEMENTATION_STATUS.md`.
