# Estado de implementação — URBIS v0.4.0-alpha.1

## Concluído e testado neste runtime

### Base territorial
- 10.997 segmentos MultiLineString operacionais;
- 82 registros preservados em quarentena;
- 46 bairros e 6 zonas;
- 2.541 referências CEP/logradouro;
- associação de ponto à malha territorial.

### Núcleo de ocorrências
- protocolo `URB-AAAAMMDD-NNNNNNN`;
- idempotência por `clientRequestId`;
- enriquecimento por logradouro/CEP/bairro/zona;
- duplicidade espaço-temporal;
- triagem;
- despacho;
- ordem de serviço;
- ciclo de atendimento e resolução;
- WebSocket.

### Identidade e autorização
- contas autenticadas na prova local;
- senha derivada com scrypt;
- token HS256 com validade temporal;
- RBAC com cinco papéis;
- cidadão limitado às próprias ocorrências;
- lista operacional bloqueada para cidadão;
- WebSocket operacional protegido por token.

### Evidência
- JPEG, PNG, WebP e MP4;
- limite de 8 MB no alpha;
- SHA-256;
- armazenamento content-addressed local na prova;
- metadados de horário e posição;
- validação técnica separada de validação administrativa;
- endpoint de validação por autoridade.

### ICI-URBIS
- algoritmo `ICI-URBIS-alpha.1`;
- seis fatores ponderados;
- resultado 0–100 e faixas qualitativas;
- recálculo após validação por autoridade;
- aviso explícito de que o índice não constitui prova automática.

### App cidadão
- web app local executável;
- login;
- GPS;
- categoria/descrição;
- foto/vídeo;
- protocolo;
- ICI;
- histórico do cidadão.

### Flutter
- estrutura de app criada;
- fluxo login/GPS/câmera/ocorrência/evidência implementado em `main.dart`;
- `pubspec.yaml` preparado.

### Backend NestJS construído em código
- AuthService, AuthGuard, RolesGuard;
- endpoints de register/login/me;
- EvidenceService e EvidenceController;
- ObjectStorageService LOCAL/S3;
- Redis Pub/Sub opcional para eventos multi-instância;
- WebSocket com autenticação;
- migration 010 para identidades, papéis, evidência e ICI.

## Testes executados

- 6 testes PLANCON;
- 4 testes territoriais;
- 4 testes do núcleo operacional;
- 5 testes de identidade/evidência/ICI;
- 4 testes E2E autenticados.

**Total: 23/23 testes automatizados aprovados**, além da validação final de datasets.

## O que não foi executado neste runtime

- inicialização real de PostgreSQL/PostGIS;
- inicialização real de Redis;
- inicialização real de MinIO/S3;
- `npm install`/build completo da API NestJS: a tentativa de instalação de dependências excedeu o tempo do ambiente e não produziu `node_modules`;
- compilação do app Flutter, pois o Flutter SDK não está disponível.

Logo, estes componentes estão **implementados em código/configuração**, mas não devem ser descritos como validados em execução nesta entrega.

## Limites técnicos ainda existentes

- OIDC/Keycloak ainda não substituiu a identidade local;
- MFA, refresh token e revogação ainda não foram implementados;
- SHA-256 não prova autenticidade prévia da mídia;
- EXIF/attestation/assinatura do dispositivo ainda não são verificados;
- antivírus e análise de conteúdo de upload ainda não estão ligados;
- ICI ainda não possui calibração empírica nem ground truth;
- política operacional LGPD de retenção, descarte e anonimização ainda precisa ser formalizada;
- painel público anonimizado ainda não foi construído;
- camadas vetoriais de risco/abrigos/rotas de evacuação continuam pendentes de fonte oficial vetorial.

## Próximo bloco

**v0.5 — Persistência real + campo + transparência**

1. executar PostGIS/Redis/MinIO em ambiente Docker;
2. migração E2E real contra PostgreSQL;
3. storage S3/MinIO testado;
4. relay Redis multi-instância testado;
5. app de equipe de campo;
6. fotos antes/depois e geofencing da OS;
7. painel público anonimizado;
8. auditoria e retenção LGPD;
9. OIDC/Keycloak;
10. ingestão vetorial das camadas de risco do PLANCON quando obtidas em formato GIS.
