# Estado de implementação — URBIS v0.3.0-alpha.1

## Concluído e testado

### Base territorial
- 10.997 segmentos MultiLineString operacionais;
- 82 registros preservados em quarentena;
- 46 bairros e 6 zonas na camada;
- 2.541 referências CEP/logradouro;
- função PostGIS de proximidade territorial.

### Núcleo de ocorrências
- criação transacional;
- protocolo concorrente `URB-AAAAMMDD-NNNNNNN`;
- idempotência por `clientRequestId`;
- vínculo com categoria;
- ponto PostGIS WGS84;
- enriquecimento automático por segmento/logradouro/CEP/bairro/zona;
- snapshot territorial auditável;
- trilha `occurrence_events`.

### Duplicidade
- busca por mesma categoria;
- raio geográfico configurável;
- janela temporal configurável;
- score espaço-temporal;
- candidatos persistidos;
- nenhuma rejeição automática: decisão fica na triagem.

### Triagem e despacho
- procedente;
- improcedente;
- duplicada;
- tabela configurável `dispatch_rules`;
- alvos institucionais abstratos para não atribuir competência sem fonte atualizada;
- geração automática de ordem de serviço;
- SLAs de engenharia explicitamente marcados como provisórios.

### Equipe / ordem de serviço
- despacho;
- aceite;
- deslocamento;
- chegada;
- início;
- conclusão;
- sincronização do status da ocorrência;
- registro de resultado da execução.

### Tempo real
- gateway WebSocket `/ws/occurrences` no backend;
- servidor WebSocket nativo equivalente na prova local;
- eventos de criação, triagem e OS;
- `realtime_outbox` durável preparado para relay Redis/Kafka.

### Painel operacional
- mapa da malha real;
- filtro territorial;
- registro manual por mapa;
- captura GPS do navegador;
- marcadores por status;
- triagem interativa;
- início e conclusão de OS;
- atualização em tempo real.

## Testes executados

- 6 testes do motor PLANCON;
- 4 testes de integridade territorial;
- 4 testes do núcleo operacional;
- 3 testes end-to-end do servidor local, incluindo WebSocket;
- validação final dos datasets.

Total atual: **17 testes automatizados**, todos aprovados, além da validação de dados.

## Limites ainda existentes

- PostgreSQL/PostGIS não pôde ser inicializado neste runtime porque Docker/PostgreSQL não estão instalados aqui; migrations e serviços estão implementados, mas a prova E2E desta entrega usa o servidor local em memória;
- autenticação/OAuth2 e RBAC ainda não estão ligados ao fluxo operacional;
- mídia foto/vídeo ainda não está ligada ao armazenamento S3/MinIO;
- Redis ainda não é o relay de eventos entre múltiplas instâncias;
- app Flutter ainda não foi iniciado;
- regras de competência administrativa precisam ser parametrizadas com os órgãos vigentes na implantação;
- geometrias de setores de risco, manchas de inundação, abrigos e rotas de evacuação ainda dependem das respectivas camadas vetoriais.

## Próximo bloco recomendado

**Bloco v0.4 — Evidência, autenticação e aplicativo cidadão**:

1. autenticação Keycloak/OIDC + RBAC;
2. upload de foto/vídeo para MinIO/S3 com SHA-256;
3. metadados EXIF/GPS sem confiar cegamente neles;
4. fluxo de validação da evidência;
5. ICI-URBIS / confiabilidade auditável;
6. aplicativo Flutter com GPS, câmera, protocolo e acompanhamento;
7. Redis Pub/Sub para múltiplas instâncias;
8. política de retenção/LGPD e anonimização do painel público.
