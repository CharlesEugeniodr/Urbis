import { BadRequestException, ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { DatabaseService } from '../database/database.service';
import { RealtimeService } from '../realtime/realtime.service';

const ALLOWED=['ACCEPTED','EN_ROUTE','ARRIVED','IN_PROGRESS','COMPLETED','CANCELLED'];
@Injectable()
export class WorkOrdersService {
  constructor(private readonly db:DatabaseService,private readonly realtime:RealtimeService){}
  async list(limitRaw?:string){const limit=Math.max(1,Math.min(Number(limitRaw)||200,1000));const q=await this.db.query(`SELECT * FROM work_orders ORDER BY created_at DESC LIMIT $1`,[limit]);return {count:q.rowCount??0,records:q.rows};}
  async updateStatus(id:string,body:Record<string,unknown>){
    const status=String(body.status??'').toUpperCase();if(!ALLOWED.includes(status)) throw new BadRequestException(`status inválido: ${status}`);
    const result=await this.db.tx(async client=>{
      const q=await client.query(`SELECT w.*,o.status AS occurrence_status FROM work_orders w JOIN occurrences o ON o.id=w.occurrence_id WHERE w.id=$1 FOR UPDATE`,[id]);
      if(!q.rowCount) throw new NotFoundException('ordem de serviço não encontrada');
      const w=q.rows[0];if(['COMPLETED','CANCELLED'].includes(w.status)) throw new ConflictException(`ordem encerrada em ${w.status}`);
      const fields:string[]=['status=$2'];const vals:any[]=[id,status];
      if(status==='IN_PROGRESS'){fields.push('started_at=COALESCE(started_at,now())')}
      if(status==='COMPLETED'){fields.push('completed_at=now()')}
      if(body.result!=null){vals.push(JSON.stringify(body.result));fields.push(`result=result || $${vals.length}::jsonb`)}
      await client.query(`UPDATE work_orders SET ${fields.join(',')} WHERE id=$1`,vals);
      let occurrenceStatus=w.occurrence_status;
      if(['ACCEPTED','EN_ROUTE','ARRIVED','IN_PROGRESS'].includes(status)) occurrenceStatus='IN_SERVICE';
      if(status==='COMPLETED') occurrenceStatus='RESOLVED';
      if(occurrenceStatus!==w.occurrence_status){
        await client.query(`UPDATE occurrences SET status=$2,updated_at=now(),resolved_at=CASE WHEN $2='RESOLVED' THEN now() ELSE resolved_at END WHERE id=$1`,[w.occurrence_id,occurrenceStatus]);
        await client.query(`INSERT INTO occurrence_events(occurrence_id,event_type,from_status,to_status,payload) VALUES($1,'WORK_ORDER_STATUS',$2,$3,$4)`,[w.occurrence_id,w.occurrence_status,occurrenceStatus,JSON.stringify({workOrderId:id,workOrderStatus:status})]);
      }
      await client.query(`INSERT INTO realtime_outbox(topic,entity_type,entity_id,payload) VALUES('work_order.status','work_order',$1,$2)`,[id,JSON.stringify({occurrenceId:w.occurrence_id,status,occurrenceStatus})]);
      return {workOrderId:id,occurrenceId:w.occurrence_id,status,occurrenceStatus};
    });
    this.realtime.publish({topic:'work_order.status',entityType:'work_order',entityId:id,payload:result});return result;
  }
}
