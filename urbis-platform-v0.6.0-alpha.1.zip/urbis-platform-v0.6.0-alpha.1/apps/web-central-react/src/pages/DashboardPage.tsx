import React from 'react';
import ReactECharts from 'echarts-for-react';
import { AlertCircle, CheckCircle, ClipboardList, Clock, Users, TimerOff } from 'lucide-react';
import { useDashboard, useOccurrences } from '../api/hooks';
import { KpiCard } from '../components/KpiCard';
import { StatusBadge } from '../components/StatusBadge';
export function DashboardPage(){const {data:d,isLoading,error}=useDashboard();const {data:recent}=useOccurrences(10);if(isLoading)return <p>Carregando dashboard...</p>;if(error||!d)return <p>Falha ao carregar dashboard.</p>;const status=d.byStatus??{};const categories=d.byCategory??{};return <>
  <div className="kpi-grid"><KpiCard title="Total" value={d.occurrences} icon={ClipboardList}/><KpiCard title="Abertas" value={status.OPEN??0} icon={AlertCircle}/><KpiCard title="Triagem" value={status.TRIAGE??0} icon={Clock}/><KpiCard title="Resolvidas" value={status.RESOLVED??0} icon={CheckCircle}/><KpiCard title="OS vencidas" value={d.overdueServiceOrders??0} icon={TimerOff}/><KpiCard title="Usuários ativos 30d" value={d.activeCitizenReporters30d??0} icon={Users}/></div>
  <div className="charts-grid"><div className="card"><ReactECharts option={{title:{text:'Ocorrências por status'},xAxis:{type:'category',data:Object.keys(status)},yAxis:{type:'value'},series:[{type:'bar',data:Object.values(status)}]}}/></div><div className="card"><ReactECharts option={{title:{text:'Por categoria'},series:[{type:'pie',radius:'60%',data:Object.entries(categories).map(([name,value])=>({name,value}))}]}}/></div></div>
  <div className="card"><h3>Ocorrências recentes</h3><table><thead><tr><th>Protocolo</th><th>Categoria</th><th>Status</th><th>Bairro</th></tr></thead><tbody>{recent?.records?.map((o:any)=><tr key={o.id}><td>{o.protocol}</td><td>{o.categoryCode}</td><td><StatusBadge status={o.status}/></td><td>{o.territory?.neighborhood??'—'}</td></tr>)}</tbody></table></div>
</>}
