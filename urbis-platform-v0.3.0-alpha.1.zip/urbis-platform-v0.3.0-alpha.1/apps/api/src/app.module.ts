import { Module } from '@nestjs/common';
import { HealthController } from './health/health.controller';
import { ResilienceController } from './resilience/resilience.controller';
import { TerritoryController } from './territory/territory.controller';
import { OccurrencesController } from './occurrences/occurrences.controller';
import { OperationsController } from './occurrences/operations.controller';
import { OccurrencesService } from './occurrences/occurrences.service';
import { WorkOrdersController } from './dispatch/work-orders.controller';
import { WorkOrdersService } from './dispatch/work-orders.service';
import { DatabaseService } from './database/database.service';
import { RealtimeService } from './realtime/realtime.service';
import { RealtimeGateway } from './realtime/realtime.gateway';
@Module({
  controllers:[HealthController,ResilienceController,TerritoryController,OccurrencesController,OperationsController,WorkOrdersController],
  providers:[DatabaseService,RealtimeService,RealtimeGateway,OccurrencesService,WorkOrdersService]
})
export class AppModule {}
