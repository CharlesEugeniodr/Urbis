# URBIS v0.6.0-alpha.1 — Auditoria de reconciliação

## Escopo
Reconciliação aditiva entre a baseline auditada v0.5.0-alpha.1 e a evolução posterior analisada no GitHub `CharlesEugeniodr/Urbis`.

### Referências
- baseline: `f4273dfd4ca40c412eb5a9a09869f521ea107b4b`;
- GitHub analisado: `88fcb4aa8df4910797b25f2d938dc14c4e4b6394`;
- versão reconciliada: `0.6.0-alpha.1`.

## Fusões materializadas
- núcleo v0.5 preservado;
- App Cidadão expandido sem regressão de GPS/câmera;
- GPS real e precisão GNSS enviados à API;
- evidência fotográfica restaurada no fluxo cidadão;
- protocolo oficial apresentado após criação;
- Central React modularizada;
- DTOs snake_case/camelCase normalizados;
- Central corrigida para `/v1/work-orders`;
- KPI de OS vencidas ligado ao backend;
- WebSocket nativo ligado ao painel;
- auditoria conectada a `/v1/audit/events`;
- MapLibre definido em `^6.4.1`, retirando a versão 4.7.1 identificada pelo CI com CVE-2026-85061;
- versão elevada para v0.6.0-alpha.1.

## Testes executados neste ambiente
`npm run test:all`: **43/43 testes funcionais aprovados**.

Distribuição:
- 6 PLANCON;
- 4 território;
- 4 operação;
- 5 segurança/evidência;
- 9 negócio;
- 3 reporting;
- 12 E2E.

Datasets:
- 2.541 registros CEP;
- 10.997 segmentos GIS;
- 82 registros em quarentena.

Cobertura do núcleo:
- linhas: **93,30%**;
- funções: **89,38%**;
- branches: **57,84%**.

Prova de carga local v0.6:
- 10.000 requisições;
- concorrência 100;
- 0 erros;
- p95: **41,38 ms**;
- throughput observado: **3.976,49 req/s**;
- escopo: `LOCAL_IN_MEMORY_PROOF_NOT_PRODUCTION`.

## Não declarado como comprovado
- build Flutter desta árvore reconciliada, porque o SDK Flutter não existe no runtime atual;
- build React/NestJS/Next da árvore reconciliada, porque as dependências não estão instaladas no runtime atual;
- Trivy da nova árvore, que deverá rodar no CI após sincronização com GitHub;
- PostGIS/Redis/MinIO/Redpanda/Keycloak/FCM reais em staging;
- SLA 99,5%/99,9%;
- WCAG AA;
- p95 de produção.

## Estado do GitHub
Foram tentadas operações de escrita para criar branch e documento de reconciliação diretamente no repositório conectado. A integração GitHub retornou HTTP 403 `Resource not accessible by integration`. Portanto, esta árvore foi materializada localmente e não é declarada como já enviada ao GitHub.

## Decisão
A v0.6.0-alpha.1 é a base reconciliada recomendada para substituir o desenvolvimento divergente após sincronização controlada e CI verde.
