import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { fetchApi, normalizeOccurrence } from './client';

export const useDashboard = () => useQuery({ queryKey: ['dashboard'], queryFn: () => fetchApi('/v1/dashboard/summary') });
export const useOccurrences = (limit = 100) => useQuery({
  queryKey: ['occurrences', limit],
  queryFn: async () => {
    const data = await fetchApi(`/v1/occurrences?limit=${limit}`);
    return { ...data, records: (data.records ?? []).map(normalizeOccurrence) };
  },
});
export const useMapOccurrences = () => useQuery({
  queryKey: ['occurrences-map'],
  queryFn: async () => {
    const data = await fetchApi('/v1/occurrences/map?limit=1000');
    return { ...data, records: (data.records ?? []).map(normalizeOccurrence) };
  },
});
export const useOccurrenceDetail = (id?: string) => useQuery({
  queryKey: ['occurrence', id],
  queryFn: async () => normalizeOccurrence(await fetchApi(`/v1/occurrences/${id}`)),
  enabled: Boolean(id),
});
export const useServiceOrders = () => useQuery({ queryKey: ['work-orders'], queryFn: () => fetchApi('/v1/work-orders?limit=500') });
export const useTeams = () => useQuery({ queryKey: ['teams'], queryFn: () => fetchApi('/v1/teams') });
export const useTriageMutation = () => {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({ id, decision, priority }: { id: string; decision: string; priority?: string }) =>
      fetchApi(`/v1/occurrences/${id}/triage`, { method: 'POST', body: JSON.stringify({ decision, ...(priority ? { priority } : {}) }) }),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ['occurrences'] });
      client.invalidateQueries({ queryKey: ['occurrence'] });
      client.invalidateQueries({ queryKey: ['dashboard'] });
      client.invalidateQueries({ queryKey: ['work-orders'] });
    },
  });
};
export const useAssignTeamMutation = () => {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({ id, teamId }: { id: string; teamId: string }) => fetchApi(`/v1/work-orders/${id}/assign-team`, { method: 'POST', body: JSON.stringify({ teamId }) }),
    onSuccess: () => client.invalidateQueries({ queryKey: ['work-orders'] }),
  });
};
