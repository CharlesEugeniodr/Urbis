import React from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { AuthProvider } from './auth/AuthContext';
import { LoginPage } from './auth/LoginPage';
import { RequireAuth } from './auth/RequireAuth';
import { MainLayout } from './layout/MainLayout';
import { DashboardPage } from './pages/DashboardPage';
import { MapPage } from './pages/MapPage';
import { IncidentListPage } from './pages/IncidentListPage';
import { IncidentDetailPage } from './pages/IncidentDetailPage';
import { ServiceOrdersPage } from './pages/ServiceOrdersPage';
import { ReportsPage } from './pages/ReportsPage';
import { AuditPage } from './pages/AuditPage';
export function App(){return <AuthProvider><BrowserRouter><Routes><Route path="/login" element={<LoginPage/>}/><Route element={<RequireAuth/>}><Route element={<MainLayout/>}><Route path="/" element={<DashboardPage/>}/><Route path="/mapa" element={<MapPage/>}/><Route path="/ocorrencias" element={<IncidentListPage/>}/><Route path="/ocorrencias/:id" element={<IncidentDetailPage/>}/><Route path="/os" element={<ServiceOrdersPage/>}/><Route path="/relatorios" element={<ReportsPage/>}/><Route path="/auditoria" element={<AuditPage/>}/></Route></Route></Routes></BrowserRouter></AuthProvider>}
