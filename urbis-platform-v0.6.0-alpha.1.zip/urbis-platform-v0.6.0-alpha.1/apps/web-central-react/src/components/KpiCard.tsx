import React from 'react';
import type { LucideIcon } from 'lucide-react';
export function KpiCard({title,value,icon:Icon}:{title:string;value:any;icon:LucideIcon}){return <div className="kpi-card"><Icon size={22}/><div><small>{title}</small><strong>{value??'—'}</strong></div></div>;}
