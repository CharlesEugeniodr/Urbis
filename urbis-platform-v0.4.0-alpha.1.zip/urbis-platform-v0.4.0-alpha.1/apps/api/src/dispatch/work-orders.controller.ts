import { Body, Controller, Get, Param, Post, Query, UseGuards } from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard';
import { Roles } from '../auth/auth.decorators';
import { RolesGuard } from '../auth/roles.guard';
import { WorkOrdersService } from './work-orders.service';
@Controller('v1/work-orders') @UseGuards(AuthGuard,RolesGuard)
export class WorkOrdersController {
  constructor(private readonly service:WorkOrdersService){}
  @Get() @Roles('OPERATOR','FIELD_AGENT','MANAGER','ADMIN') list(@Query('limit') limit?:string){return this.service.list(limit);}
  @Post(':id/status') @Roles('FIELD_AGENT','MANAGER','ADMIN') status(@Param('id') id:string,@Body() body:Record<string,unknown>){return this.service.updateStatus(id,body);}
}
