import React from 'react';
export function StatusBadge({status}:{status?:string}){return <span className={`badge status-${String(status||'UNKNOWN').toLowerCase()}`}>{status||'—'}</span>;}
