import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import { AuthService } from './auth.service';
@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private readonly auth:AuthService){}
  canActivate(context:ExecutionContext){const req=context.switchToHttp().getRequest();const raw=String(req.headers.authorization??'');const m=raw.match(/^Bearer\s+(.+)$/i);if(!m)throw new UnauthorizedException('autenticação obrigatória');req.urbisUser=this.auth.verifyAccessToken(m[1]);return true;}
}
