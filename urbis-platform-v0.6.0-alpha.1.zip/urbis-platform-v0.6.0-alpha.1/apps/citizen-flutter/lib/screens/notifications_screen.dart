import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/api_client.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Notificações')),
    body: FutureBuilder<Map<String,dynamic>>(
      future: context.read<ApiClient>().notifications(),
      builder: (_, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
        if (snapshot.hasError) return Center(child: Text(snapshot.error.toString()));
        final rows = List<Map<String,dynamic>>.from((snapshot.data?['records'] ?? []).map((e)=>Map<String,dynamic>.from(e)));
        return ListView.builder(itemCount:rows.length,itemBuilder:(_,i){final n=rows[i];return ListTile(leading:const Icon(Icons.notifications_outlined),title:Text(n['template_code']?.toString() ?? n['templateCode']?.toString() ?? 'Atualização'),subtitle:Text(n['created_at']?.toString() ?? n['createdAt']?.toString() ?? ''));});
      },
    ),
  );
}
