import { NestFactory } from '@nestjs/core';
import { WsAdapter } from '@nestjs/platform-ws';
import { json } from 'express';
import { AppModule } from './app.module';
async function bootstrap(){
  const app=await NestFactory.create(AppModule,{bodyParser:false});
  app.use(json({limit:'12mb'}));
  app.useWebSocketAdapter(new WsAdapter(app));
  const corsOrigin=process.env.URBIS_CORS_ORIGIN;
  app.enableCors(corsOrigin?{origin:corsOrigin.split(',').map(v=>v.trim()),allowedHeaders:['content-type','authorization']}:{origin:false});
  await app.listen(Number(process.env.PORT??3000));
}
bootstrap();
