import 'package:flutter/material.dart';

const categories = <(String, String, IconData)>[
  ('LIGHTING', 'Iluminação', Icons.lightbulb_outline),
  ('TRAFFIC_SIGNAL', 'Trânsito', Icons.traffic_outlined),
  ('WATER', 'Água', Icons.water_drop_outlined),
  ('ENERGY', 'Energia', Icons.bolt_outlined),
  ('PAVEMENT', 'Pavimentação', Icons.construction_outlined),
  ('RESILIENCE', 'Resiliência', Icons.warning_amber_outlined),
];

class CategorySelector extends StatelessWidget {
  const CategorySelector({super.key, required this.selected, required this.onSelect});
  final String? selected;
  final ValueChanged<String> onSelect;
  @override
  Widget build(BuildContext context) => Wrap(
        spacing: 8,
        runSpacing: 8,
        children: categories.map((c) => ChoiceChip(
          avatar: Icon(c.$3, size: 18),
          label: Text(c.$2),
          selected: selected == c.$1,
          onSelected: (_) => onSelect(c.$1),
        )).toList(),
      );
}
