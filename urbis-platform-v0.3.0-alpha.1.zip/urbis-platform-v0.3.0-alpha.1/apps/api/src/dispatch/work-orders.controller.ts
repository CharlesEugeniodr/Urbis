import { Body, Controller, Get, Param, Post, Query } from '@nestjs/common';
import { WorkOrdersService } from './work-orders.service';
@Controller('v1/work-orders')
export class WorkOrdersController {
  constructor(private readonly service:WorkOrdersService){}
  @Get() list(@Query('limit') limit?:string){return this.service.list(limit);}
  @Post(':id/status') status(@Param('id') id:string,@Body() body:Record<string,unknown>){return this.service.updateStatus(id,body);}
}
