import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';

class ApiClient {
  static const String baseUrl = String.fromEnvironment(
    'URBIS_API_URL',
    defaultValue: 'http://10.0.2.2:3100',
  );

  final _storage = const FlutterSecureStorage();
  String? _token;

  Future<void> init() async {
    _token = await _storage.read(key: 'urbis_access_token');
  }

  bool get hasToken => _token != null && _token!.isNotEmpty;

  Future<void> setToken(String? token) async {
    _token = token;
    if (token == null || token.isEmpty) {
      await _storage.delete(key: 'urbis_access_token');
    } else {
      await _storage.write(key: 'urbis_access_token', value: token);
    }
  }

  Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        if (_token != null) 'Authorization': 'Bearer $_token',
      };

  Future<Map<String, dynamic>> request(
    String path, {
    String method = 'GET',
    Map<String, dynamic>? body,
    bool auth = true,
  }) async {
    final headers = Map<String, String>.from(_headers);
    if (!auth) headers.remove('Authorization');
    final uri = Uri.parse('$baseUrl$path');
    late http.Response response;
    switch (method.toUpperCase()) {
      case 'POST':
        response = await http.post(uri, headers: headers, body: jsonEncode(body ?? {}));
        break;
      case 'PUT':
        response = await http.put(uri, headers: headers, body: jsonEncode(body ?? {}));
        break;
      default:
        response = await http.get(uri, headers: headers);
    }
    Map<String, dynamic> decoded = {};
    if (response.body.isNotEmpty) {
      final value = jsonDecode(response.body);
      if (value is Map<String, dynamic>) decoded = value;
    }
    if (response.statusCode < 200 || response.statusCode >= 300) {
      if (response.statusCode == 401) await setToken(null);
      throw Exception(decoded['message'] ?? decoded['error'] ?? 'HTTP ${response.statusCode}');
    }
    return decoded;
  }

  Future<Map<String, dynamic>> login(String email, String password) async {
    final data = await request('/v1/auth/login', method: 'POST', auth: false, body: {
      'email': email.trim(),
      'password': password,
    });
    await setToken(data['accessToken'] as String?);
    return data;
  }

  Future<Map<String, dynamic>> register({
    required String email,
    required String password,
    required String displayName,
    String? cpf,
  }) async {
    final data = await request('/v1/auth/register', method: 'POST', auth: false, body: {
      'email': email.trim(),
      'password': password,
      'displayName': displayName.trim(),
      if (cpf != null && cpf.trim().isNotEmpty) 'cpf': cpf.trim(),
    });
    await setToken(data['accessToken'] as String?);
    return data;
  }

  Future<Map<String, dynamic>> me() => request('/v1/auth/me');
  Future<Map<String, dynamic>> myOccurrences() => request('/v1/me/occurrences');
  Future<Map<String, dynamic>> ranking() => request('/v1/rankings/current');
  Future<Map<String, dynamic>> notifications() => request('/v1/me/notifications');
  Future<Map<String, dynamic>> myScore() => request('/v1/me/score');

  Future<Position> locate() async {
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
      throw Exception('Permissão de localização negada');
    }
    if (!await Geolocator.isLocationServiceEnabled()) {
      throw Exception('Ative o serviço de localização do dispositivo');
    }
    return Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
  }

  Future<Map<String, dynamic>> createOccurrence({
    required String categoryCode,
    required String description,
    required Position position,
  }) {
    return request('/v1/occurrences', method: 'POST', body: {
      'categoryCode': categoryCode,
      'description': description.trim(),
      'latitude': position.latitude,
      'longitude': position.longitude,
      'gpsAccuracyM': position.accuracy,
      'clientRequestId': 'mobile-${DateTime.now().microsecondsSinceEpoch}',
    });
  }

  Future<Map<String, dynamic>> uploadEvidence({
    required String occurrenceId,
    required XFile file,
    required Position position,
    String purpose = 'REPORT',
  }) async {
    final Uint8List bytes = await file.readAsBytes();
    return request('/v1/occurrences/$occurrenceId/evidence', method: 'POST', body: {
      'filename': file.name,
      'mediaType': file.mimeType ?? 'image/jpeg',
      'dataBase64': base64Encode(bytes),
      'purpose': purpose,
      'capturedAt': DateTime.now().toUtc().toIso8601String(),
      'latitude': position.latitude,
      'longitude': position.longitude,
      'gpsAccuracyM': position.accuracy,
    });
  }

  Future<Map<String, dynamic>> evaluate(String occurrenceId, int rating, String comment) {
    return request('/v1/occurrences/$occurrenceId/evaluation', method: 'POST', body: {
      'rating': rating,
      'comment': comment.trim(),
    });
  }

  Future<Map<String, dynamic>> registerDevice(String token, String platform) {
    return request('/v1/me/devices', method: 'POST', body: {
      'token': token,
      'platform': platform,
    });
  }
}
