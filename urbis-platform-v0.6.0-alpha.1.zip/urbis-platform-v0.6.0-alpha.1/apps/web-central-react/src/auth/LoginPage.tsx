import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { fetchApi } from '../api/client';
import { useAuth } from './AuthContext';
export function LoginPage() {
  const [email, setEmail] = useState(''); const [password, setPassword] = useState(''); const [error, setError] = useState(''); const [busy, setBusy] = useState(false);
  const auth = useAuth(); const navigate = useNavigate();
  async function submit(e: React.FormEvent) { e.preventDefault(); setBusy(true); setError(''); try { const data = await fetchApi('/v1/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) }); auth.login(data.accessToken, data.user); navigate('/'); } catch (err: any) { setError(err.message); } finally { setBusy(false); } }
  return <div className="login-page"><form className="login-card" onSubmit={submit}><h1>URBIS Central</h1><p>Central integrada de ocorrências georreferenciadas</p>{error && <div className="error-box">{error}</div>}<label>E-mail<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required /></label><label>Senha<input type="password" value={password} onChange={e=>setPassword(e.target.value)} required /></label><button className="btn-primary" disabled={busy}>{busy?'Entrando...':'Entrar'}</button></form></div>;
}
