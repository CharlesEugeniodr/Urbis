import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/api_client.dart';

class RankingScreen extends StatelessWidget {
  const RankingScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Ranking cidadão')),
    body: FutureBuilder<Map<String,dynamic>>(
      future: context.read<ApiClient>().ranking(),
      builder: (_, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
        if (snapshot.hasError) return Center(child: Text(snapshot.error.toString()));
        final rows = List<Map<String,dynamic>>.from((snapshot.data?['records'] ?? []).map((e)=>Map<String,dynamic>.from(e)));
        return ListView.builder(itemCount: rows.length,itemBuilder:(_,i){final r=rows[i];return ListTile(leading: CircleAvatar(child: Text('${r['position'] ?? i+1}')),title:Text(r['display_name']?.toString() ?? r['displayName']?.toString() ?? 'Cidadão'),trailing:Text('${r['points'] ?? 0} pts'));});
      },
    ),
  );
}
