FROM node:22-alpine AS build
WORKDIR /app
COPY apps/api/package.json ./package.json
RUN npm install
COPY apps/api/tsconfig.json ./tsconfig.json
COPY apps/api/src ./src
RUN npm run build
FROM node:22-alpine
WORKDIR /app
ENV NODE_ENV=production
COPY apps/api/package.json ./package.json
RUN npm install --omit=dev
COPY --from=build /app/dist ./dist
CMD ["node","dist/main.js"]
