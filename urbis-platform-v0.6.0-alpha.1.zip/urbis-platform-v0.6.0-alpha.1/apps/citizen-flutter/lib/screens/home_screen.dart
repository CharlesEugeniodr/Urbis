import 'package:flutter/material.dart';
import 'new_occurrence_screen.dart';
import 'history_screen.dart';
import 'ranking_screen.dart';
import 'notifications_screen.dart';
import 'profile_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('URBIS Cidadão')),
        body: GridView.count(
          crossAxisCount: 2,
          padding: const EdgeInsets.all(16),
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          children: [
            _tile(context, Icons.add_location_alt_outlined, 'Nova ocorrência', const NewOccurrenceScreen()),
            _tile(context, Icons.history, 'Histórico', const HistoryScreen()),
            _tile(context, Icons.emoji_events_outlined, 'Ranking', const RankingScreen()),
            _tile(context, Icons.notifications_outlined, 'Notificações', const NotificationsScreen()),
            _tile(context, Icons.person_outline, 'Perfil', const ProfileScreen()),
          ],
        ),
      );

  Widget _tile(BuildContext context, IconData icon, String label, Widget screen) => Card(
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => screen)),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, size: 42), const SizedBox(height: 8), Text(label, textAlign: TextAlign.center)]),
        ),
      );
}
