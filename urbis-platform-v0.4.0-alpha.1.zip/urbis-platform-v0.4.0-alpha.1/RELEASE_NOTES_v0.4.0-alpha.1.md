# URBIS v0.4.0-alpha.1 — Release Notes

## Escopo

Bloco **Identidade + Evidência + App Cidadão** construído sobre a v0.3.0-alpha.1.

## Entregas

### 1. Identidade e RBAC
- hash de senha com scrypt na prova local e API;
- token HS256 com expiração, issuer e audience;
- papéis `CITIZEN`, `OPERATOR`, `FIELD_AGENT`, `MANAGER`, `ADMIN`;
- autorização por função nos endpoints operacionais;
- histórico do próprio cidadão em `/v1/me/occurrences`;
- WebSocket operacional protegido por token.

### 2. Evidência digital
- upload de JPEG/PNG/WebP/MP4;
- limite alpha de 8 MB;
- SHA-256 do conteúdo;
- armazenamento content-addressed;
- metadados de captura e coordenadas da evidência;
- validação de autoridade separada da validação técnica;
- nova migration de persistência.

### 3. ICI-URBIS
- algoritmo versionado `ICI-URBIS-alpha.1`;
- fatores de fonte, geografia, evidência, tempo, corroboração e autoridade;
- avaliações persistíveis e auditáveis;
- interpretação explicitamente limitada: indicador de engenharia, não prova automática.

### 4. App cidadão
- prova web executável em `/citizen/`;
- login;
- GPS;
- categoria e descrição;
- foto/vídeo;
- protocolo;
- retorno do ICI;
- histórico das próprias ocorrências.

### 5. Flutter
- starter em `apps/citizen-flutter`;
- login, GPS, câmera, ocorrência e upload de evidência implementados em código;
- não compilado por ausência do Flutter SDK no runtime.

### 6. Infraestrutura
- Redis Pub/Sub opcional no backend NestJS para múltiplas instâncias;
- storage abstraction LOCAL/S3;
- MinIO com bucket privado provisionado no Compose;
- migration `010_identity_evidence_ici.sql`.

## Testes executados

**23/23 aprovados**, além da validação integral dos datasets.

O E2E cobre:

1. cidadão impedido de acessar lista operacional;
2. ocorrência autenticada;
3. upload de evidência e verificação SHA-256;
4. cálculo ICI;
5. validação por autoridade;
6. duplicidade;
7. triagem;
8. ordem de serviço;
9. resolução;
10. idempotência;
11. WebSocket autenticado.

## Restrições objetivas

A execução PostGIS/Redis/MinIO e o build Flutter continuam não comprovados neste runtime. As migrations, serviços e configurações estão incluídos, mas não devem ser declarados como executados até teste em ambiente com Docker/PostgreSQL/Redis/MinIO/Flutter.
