import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { evaluateResilience } from '../core/risk-engine.mjs';
import { advanceWorkOrder, buildOccurrence, nearestStreet, triageOccurrence } from '../core/operation-core.mjs';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const root=path.join(__dirname,'..');
const VERSION='0.3.0-alpha.1';
const PORT=Number(process.env.URBIS_PORT??3100);
const HOST=process.env.URBIS_HOST??'127.0.0.1';

const csv=fs.readFileSync(path.join(root,'data/territorial/ceps_parauapebas_2025.csv'),'utf8').split(/\r?\n/);
const header=csv[0].split(',');
function parseCsvLine(line){const out=[];let cur='',q=false;for(let i=0;i<line.length;i++){const c=line[i];if(c==='"'){if(q&&line[i+1]==='"'){cur+='"';i++;}else q=!q;}else if(c===','&&!q){out.push(cur);cur='';}else cur+=c;}out.push(cur);return Object.fromEntries(header.map((h,i)=>[h,out[i]??'']));}
const cepIndex=new Map();for(const line of csv.slice(1)){if(!line.trim())continue;const r=parseCsvLine(line);if(!cepIndex.has(r.cep))cepIndex.set(r.cep,[]);cepIndex.get(r.cep).push(r);}

const streetsPath=path.join(root,'data/territorial/logradouros_parauapebas_2025.operational.geojson');
const streets=JSON.parse(fs.readFileSync(streetsPath,'utf8'));
const streetMeta=JSON.parse(fs.readFileSync(path.join(root,'data/territorial/logradouros_parauapebas_2025.metadata.json'),'utf8'));
const operationalFeatures=streets.features;

const state={occurrences:[],workOrders:[],events:[],protocolSeq:1};
const wsClients=new Set();
function protocol(){return `URB-${new Date().toISOString().slice(0,10).replaceAll('-','')}-${String(state.protocolSeq++).padStart(7,'0')}`;}
function event(topic,entityType,entityId,payload){const e={topic,entityType,entityId,payload,at:new Date().toISOString()};state.events.push(e);for(const s of wsClients)sendWs(s,JSON.stringify(e));return e;}

function send(res,code,obj,extra={}){const body=JSON.stringify(obj,null,2);res.writeHead(code,{'content-type':'application/json; charset=utf-8','access-control-allow-origin':'*','access-control-allow-headers':'content-type','access-control-allow-methods':'GET,POST,OPTIONS',...extra});res.end(body);}
function sendFile(res,file,contentType){res.writeHead(200,{'content-type':contentType,'access-control-allow-origin':'*','cache-control':'no-store'});fs.createReadStream(file).pipe(res);}
function bodyJson(req){return new Promise((resolve,reject)=>{let body='';req.on('data',c=>{body+=c;if(body.length>2_000_000){reject(new Error('body_too_large'));req.destroy();}});req.on('end',()=>{try{resolve(JSON.parse(body||'{}'));}catch{reject(new Error('invalid_json'));}});req.on('error',reject);});}
function eachCoord(geom,fn){if(!geom)return;const c=geom.coordinates;if(geom.type==='MultiLineString')for(const line of c)for(const p of line)fn(p);else if(geom.type==='LineString')for(const p of c)fn(p);}
function featureBounds(ft){let b=[180,90,-180,-90];eachCoord(ft.geometry,([x,y])=>{b[0]=Math.min(b[0],x);b[1]=Math.min(b[1],y);b[2]=Math.max(b[2],x);b[3]=Math.max(b[3],y);});return b;}
const features=operationalFeatures.map(ft=>({ft,bbox:featureBounds(ft)}));
function intersects(a,b){return a[0]<=b[2]&&a[2]>=b[0]&&a[1]<=b[3]&&a[3]>=b[1];}
function parseBbox(v){if(!v)return null;const p=v.split(',').map(Number);return p.length===4&&p.every(Number.isFinite)?p:null;}
function summary(){const byStatus={};for(const o of state.occurrences)byStatus[o.status]=(byStatus[o.status]??0)+1;return {occurrences:state.occurrences.length,workOrders:state.workOrders.length,byStatus,websocketClients:wsClients.size,eventCount:state.events.length};}
function territoryFor(lon,lat){const n=nearestStreet(operationalFeatures,lon,lat,120);if(!n)return {matched:false};const p=n.feature.properties;return {matched:true,streetSegmentSourceIndex:p._source_index??null,streetName:p.nom_novo??p.logradouro??null,streetType:p.tipo_log??null,cep:p.cep??null,neighborhood:p.bairro??null,zone:p.Zona??null,distanceM:Number(n.distanceM.toFixed(3)),source:'Logradouros 2025'};}
function getOccurrence(id){return state.occurrences.find(o=>o.id===id);}
function getWorkOrder(id){return state.workOrders.find(w=>w.id===id);}

const panelDir=path.join(root,'apps/panel-gis-proof');
const server=http.createServer(async(req,res)=>{
  const u=new URL(req.url||'/',`http://${HOST}:${PORT}`);
  if(req.method==='OPTIONS'){res.writeHead(204,{'access-control-allow-origin':'*','access-control-allow-headers':'content-type','access-control-allow-methods':'GET,POST,OPTIONS'});return res.end();}
  try{
    if(req.method==='GET'&&u.pathname==='/health')return send(res,200,{status:'ok',service:'urbis-local-probe',version:VERSION,street_features:operationalFeatures.length,...summary()});
    if(req.method==='GET'&&u.pathname==='/v1/operations/summary')return send(res,200,summary());
    if(req.method==='GET'&&u.pathname==='/v1/territory/stats')return send(res,200,streetMeta);
    const cm=u.pathname.match(/^\/v1\/territory\/cep\/(\d{5}-?\d{3})$/);
    if(req.method==='GET'&&cm){const cep=cm[1].includes('-')?cm[1]:cm[1].slice(0,5)+'-'+cm[1].slice(5);const rows=cepIndex.get(cep)||[];return send(res,rows.length?200:404,{cep,count:rows.length,records:rows});}
    if(req.method==='GET'&&u.pathname==='/v1/territory/streets'){const bbox=parseBbox(u.searchParams.get('bbox')),limit=Math.max(1,Math.min(Number(u.searchParams.get('limit')||500),5000)),bairro=(u.searchParams.get('bairro')||'').toLowerCase(),zone=(u.searchParams.get('zone')||'').toLowerCase();const arr=features.filter(({ft,bbox:fb})=>(!bbox||intersects(fb,bbox))&&(!bairro||String(ft.properties.bairro||'').toLowerCase()===bairro)&&(!zone||String(ft.properties.Zona||'').toLowerCase()===zone)).slice(0,limit).map(x=>x.ft);return send(res,200,{type:'FeatureCollection',count:arr.length,features:arr});}
    if(req.method==='GET'&&u.pathname==='/v1/territory/nearest'){const lat=Number(u.searchParams.get('lat')),lon=Number(u.searchParams.get('lon'));if(!Number.isFinite(lat)||!Number.isFinite(lon))return send(res,400,{error:'lat_lon_required'});const n=nearestStreet(operationalFeatures,lon,lat,120);return send(res,200,{query:{lat,lon},result:n?{distance_m:n.distanceM,properties:n.feature.properties}:null});}
    if(req.method==='POST'&&u.pathname==='/v1/resilience/evaluate'){const b=await bodyJson(req);return send(res,200,evaluateResilience(b));}

    if(req.method==='GET'&&u.pathname==='/v1/occurrences'){let records=[...state.occurrences].sort((a,b)=>Date.parse(b.createdAt)-Date.parse(a.createdAt));const status=u.searchParams.get('status'),cat=u.searchParams.get('categoryCode');if(status)records=records.filter(o=>o.status===status.toUpperCase());if(cat)records=records.filter(o=>o.categoryCode===cat.toUpperCase());return send(res,200,{count:records.length,records});}
    if(req.method==='POST'&&u.pathname==='/v1/occurrences'){
      const b=await bodyJson(req);if(b.clientRequestId){const prior=state.occurrences.find(o=>o.clientRequestId===b.clientRequestId);if(prior)return send(res,200,{occurrence:prior,duplicates:[],idempotent:true});}
      const territory=territoryFor(Number(b.longitude),Number(b.latitude));const built=buildOccurrence(b,{protocol:protocol(),territory,existing:state.occurrences});built.occurrence.clientRequestId=b.clientRequestId??null;state.occurrences.push(built.occurrence);event('occurrence.created','occurrence',built.occurrence.id,built);return send(res,201,{...built,idempotent:false});
    }
    const om=u.pathname.match(/^\/v1\/occurrences\/([0-9a-f-]+)$/i);
    if(req.method==='GET'&&om){const o=getOccurrence(om[1]);if(!o)return send(res,404,{error:'occurrence_not_found'});return send(res,200,{...o,workOrders:state.workOrders.filter(w=>w.occurrenceId===o.id)});}
    const tm=u.pathname.match(/^\/v1\/occurrences\/([0-9a-f-]+)\/triage$/i);
    if(req.method==='POST'&&tm){const o=getOccurrence(tm[1]);if(!o)return send(res,404,{error:'occurrence_not_found'});const b=await bodyJson(req);const duplicateOf=b.duplicateOf??(String(b.decision).toUpperCase()==='DUPLICATE'?state.occurrences.find(x=>x.id!==o.id&&x.categoryCode===o.categoryCode)?.id:null);const out=triageOccurrence(o,b.decision,{duplicateOf,notes:b.notes});Object.assign(o,out.occurrence);if(out.workOrder)state.workOrders.push(out.workOrder);event('occurrence.triaged','occurrence',o.id,{occurrence:o,workOrder:out.workOrder});return send(res,200,{occurrence:o,workOrder:out.workOrder});}

    if(req.method==='GET'&&u.pathname==='/v1/work-orders')return send(res,200,{count:state.workOrders.length,records:[...state.workOrders].reverse()});
    const wm=u.pathname.match(/^\/v1\/work-orders\/([0-9a-f-]+)\/status$/i);
    if(req.method==='POST'&&wm){const w=getWorkOrder(wm[1]);if(!w)return send(res,404,{error:'work_order_not_found'});const o=getOccurrence(w.occurrenceId);const b=await bodyJson(req);const out=advanceWorkOrder(w,o,b.status,{result:b.result??null});Object.assign(w,out.workOrder);Object.assign(o,out.occurrence);event('work_order.status','work_order',w.id,{workOrder:w,occurrence:o});return send(res,200,{workOrder:w,occurrence:o});}

    if(req.method==='GET'&&(u.pathname==='/'||u.pathname==='/panel'||u.pathname==='/panel/'))return sendFile(res,path.join(panelDir,'index.html'),'text/html; charset=utf-8');
    if(req.method==='GET'&&u.pathname==='/panel/app.js')return sendFile(res,path.join(panelDir,'app.js'),'text/javascript; charset=utf-8');
    if(req.method==='GET'&&u.pathname==='/panel/styles.css')return sendFile(res,path.join(panelDir,'styles.css'),'text/css; charset=utf-8');
    if(req.method==='GET'&&u.pathname==='/data/streets.geojson')return sendFile(res,streetsPath,'application/geo+json; charset=utf-8');
    return send(res,404,{error:'not_found'});
  }catch(e){return send(res,400,{error:String(e?.message??e)});}
});

function wsFrame(text){const p=Buffer.from(text);if(p.length<126)return Buffer.concat([Buffer.from([0x81,p.length]),p]);if(p.length<65536){const h=Buffer.alloc(4);h[0]=0x81;h[1]=126;h.writeUInt16BE(p.length,2);return Buffer.concat([h,p]);}const h=Buffer.alloc(10);h[0]=0x81;h[1]=127;h.writeBigUInt64BE(BigInt(p.length),2);return Buffer.concat([h,p]);}
function sendWs(socket,text){try{socket.write(wsFrame(text));}catch{wsClients.delete(socket);}}
server.on('upgrade',(req,socket)=>{const u=new URL(req.url||'/',`http://${HOST}:${PORT}`);if(u.pathname!=='/ws/occurrences'){socket.destroy();return;}const key=req.headers['sec-websocket-key'];if(!key){socket.destroy();return;}const accept=crypto.createHash('sha1').update(key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+accept+'\r\n\r\n');wsClients.add(socket);sendWs(socket,JSON.stringify({topic:'connection.ready',entityType:'system',entityId:'local-probe',payload:{version:VERSION},at:new Date().toISOString()}));socket.on('close',()=>wsClients.delete(socket));socket.on('error',()=>wsClients.delete(socket));socket.on('end',()=>wsClients.delete(socket));});

server.listen(PORT,HOST,()=>console.log(`URBIS operational proof em http://${HOST}:${PORT}/panel/`));
function shutdown(){for(const s of wsClients)s.destroy();server.close(()=>process.exit(0));setTimeout(()=>process.exit(0),500).unref();}
process.on('SIGTERM',shutdown);process.on('SIGINT',shutdown);
