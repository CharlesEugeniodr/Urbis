# Arquitetura — URBIS v0.4.0-alpha.1

## Visão de componentes

```text
App Cidadão Flutter / Web
        │ HTTPS + Bearer
        ▼
    API NestJS
 ┌──────┼─────────┬──────────────┐
 │      │         │              │
Auth  Occurrence Evidence     Resilience
 │      │         │              │
 │   PostGIS   Object Store   PLANCON rules
 │      │      LOCAL/S3          │
 │      ├─────────┘              │
 │      ▼                        │
 │  ICI-URBIS                    │
 │      │                        │
 └──────┼────────────────────────┘
        ▼
 RealtimeService
   │          │
 WebSocket  Redis Pub/Sub
   │          │
   └──── Central GIS
```

## Persistência

- PostgreSQL 16 + PostGIS 3.4;
- `occurrences` como entidade territorial principal;
- `occurrence_media` para evidência;
- `occurrence_evidence_assessments` para avaliações ICI versionadas;
- `occurrence_events` e `realtime_outbox` para trilha operacional;
- `auth_identities` e `user_roles` separados de `users_account`.

## Princípios preservados

1. **proveniência:** fonte, dataset e versão não são confundidos com observações atuais;
2. **não correção silenciosa:** geometrias inválidas permanecem em quarentena;
3. **não automação decisória absoluta:** duplicidade e ICI subsidiam triagem; não encerram ocorrência sozinhos;
4. **mínimo privilégio:** RBAC separa cidadão, operação, campo e administração;
5. **integridade de mídia:** SHA-256 após ingestão, sem alegar autenticidade anterior;
6. **multi-instância:** Redis distribui eventos entre instâncias; WebSocket entrega à Central.

## Modos de execução

### Prova local
`tools/local-probe-server.mjs`: memória + filesystem, sem dependências externas. É o alvo dos testes E2E desta entrega.

### Backend estrutural
`apps/api`: NestJS + PostgreSQL/PostGIS + Redis + LOCAL/S3. Foi construído em código, mas não executado neste runtime por ausência das dependências/serviços.
