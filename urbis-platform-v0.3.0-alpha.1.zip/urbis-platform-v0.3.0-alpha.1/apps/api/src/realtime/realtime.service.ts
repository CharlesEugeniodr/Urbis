import { Injectable } from '@nestjs/common';
import { EventEmitter } from 'node:events';

export type UrbisRealtimeEvent={topic:string;entityType:string;entityId:string;payload:Record<string,unknown>;at:string};

@Injectable()
export class RealtimeService {
  private readonly emitter=new EventEmitter();
  publish(event:Omit<UrbisRealtimeEvent,'at'>){
    const full={...event,at:new Date().toISOString()};
    this.emitter.emit('urbis',full);
    return full;
  }
  subscribe(listener:(event:UrbisRealtimeEvent)=>void){
    this.emitter.on('urbis',listener);
    return ()=>this.emitter.off('urbis',listener);
  }
}
